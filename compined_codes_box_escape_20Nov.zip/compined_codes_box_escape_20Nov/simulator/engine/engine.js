// Generated from seven combined firmware compilation units. See the original project licence and the reproducible build sources.
globalThis.BoxCore=(()=>{'use strict';
const IMAGE=[[0, "f0VMRgEBAQAAAAAAAAAAAAIAAwABAAAAczcAADQAAACQXQAAAAAAADQAIAAGACgACQAIAAEAAAAAAAAAAAAAAAAAAAD0AAAA9AAAAAQAAAAAEAAAAQAAAAAQAAAAEAAAABAAAEgsAABILAAABQAAAAAQAAABAAAAAEAAAABAAAAAQAAASAgAAEgIAAAEAAAAABAAAAEAAAD8TwAA/F8AAPxfAAAEAAAAbAIAAAYAAAAAEAAAUeV0ZAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAABAAAABS5XRk/E8AAPxfAAD8XwAABAAAAAQAAAAEAAAAAQAAAA=="], [16384, "SURMRQBDQUxJQlJBVEUAU1RSQUlHSFQAUE9JTlQAUE9JTlRfQ0NXAFBJVk9UAEVTQ0FQRQBGQVVMVAB0dXJuAHJlYWRfcHJvdHJhY3RvcgBjb2FzdABTdG9wcGVkLgBUdXJuaW5nIGNvdW50ZXJjbG9ja3dpc2UAVHVybmluZyBjbG9ja3dpc2UAVHVybiB0aW1lZCBvdXQATWVhc3VyaW5nIGNvYXN0LWRvd24ASW52YWxpZCBvZG9tZXRyeS4AU2VlayBhIHdhbGwuAFR1cm4gaW50byBjYW5kaWRhdGUgb3BlbmluZy4AQ3Jvc3NpbmcgY2FuZGlkYXRlIG9wZW5pbmcuAFJlYWNxdWlyaW5nIHJpZ2h0IHdhbGwuAE9ic2VydmF0aW9uIHRpbWVvdXQuAFJ1biBib3VuZCByZWFjaGVkLgBUdXJuIHRpbWVvdXQuAE5vIGZvcndhcmQgcHJvZ3Jlc3MuAE9ic3RhY2xlIGluIGV4aXQgcGF0aC4AT2JzdHJ1Y3RlZCB3aGlsZSBjZW50cmluZy4AT3ZlcnNob3Qgb3BlbmluZyBjZW50cmUuAEZvbGxvd2luZyByaWdodCB3YWxsLgBJZGxlOyBDIHRvIGNhbGlicmF0ZQBJbnZhbGlkIG9kb21ldHJ5IGdlb21ldHJ5AENsb2Nrd2lzZSB0dXJuIHRlc3QAQ291bnRlcmNsb2Nrd2lzZSB0dXJuIHRlc3QAU3RvcHBlZCBieSBvcGVyYXRvcgBSdW4gQyBjYWxpYnJhdGlvbiBmaXJzdABCb3VuZGVkIHN0cmFpZ2h0IHRlc3QAU2luZ2xlLWJveCB0cmlhbABPZG9tZXRyeSBkaWQgbm90IHVwZGF0ZQBDb250cm9sIHVwZGF0ZSBsYXRlAFN0cmFpZ2h0IHRlc3QgY29tcGxldGUASWRsZS4ASW5pdGlhbGlzaW5nAFNFRUsAVFVSTl9MRUZUAFNFVFRMRV9MRUZUAEFDUVVJUkUARk9MTE9XAENFTlRSRQBUVVJOX1JJR0hUAFNFVFRMRV9SSUdIVABDUk9TUwBDQU5ESURBVEUAAABUdXJuIGNvbXBsZXRlOyBjb21wYXJlIGVzdGltYXRlZCBhbmdsZSB3aXRoIHByb3RyYWN0b3IAAAAAAABSZWNvcmQgcGh5c2ljYWwgYW5nbGU7IG5leHQgc3RlcCBpbiBmaXZlIHNlY29uZHMAAAAAVHVybiBtb3ZlZCBvcHBvc2l0ZSB0byBjb21tYW5kZWQgZGlyZWN0aW9uAABUdXJuIGxlZnQgdG8ga2VlcCB3YWxsIG9uIHJpZ2h0LgAAAABUdXJuIG1vdmVkIGluIHRoZSB3cm9uZyBkaXJlY3Rpb24uAABUdXJuIHNldHRsZWQgb3V0c2lkZSB0b2xlcmFuY2UuAE5vIGZvcndhcmQgY2xlYXJhbmNlIGFmdGVyIGV4aXQgdHVybi4AAABDYW5kaWRhdGUgZXhpdDsgdmVyaWZ5IHdob2xlIGJvZHkgb3V0c2lkZS4AAENhbmRpZGF0ZSBnYXAgZGlkIG5vdCBzdGF5IG9wZW4uAAAAAE5vIGNsZWFyYW5jZSB0byByZWFjcXVpcmUgd2FsbC4ATm8gY29uZmlybWVkIHdhbGwgd2l0aGluIHNlYXJjaCBkaXN0YW5jZS4AAABPcGVuaW5nIG5vdCBjb25maXJtZWQgYmVmb3JlIGNlbnRyaW5nIHdpbmRvdyBlbmRlZC4AQ2VudHJpbmcgb24gY2FuZGlkYXRlIG9wZW5pbmcuAABSaWdodCB3YWxsIGxvc3QgYmVmb3JlIHRyYWNraW5nIHdhcyBlc3RhYmxpc2hlZC4AAAAATWVhc3VyaW5nIGZvcndhcmQgc3RhcnRpbmcgUFdNAABFc2NhcGUgUFdNIHRvbyBsb3cgZm9yIG1lYXN1cmVkIGRlYWRiYW5kOyB0dW5lIGJlZm9yZSBydW5uaW5nAAAAVHVybiBQV00gdG9vIGxvdyBmb3IgbWVhc3VyZWQgZm9yd2FyZCBkZWFkYmFuZAAARnJvbnQgdG9vIGNsb3NlIHRvIHN0YXJ0IHN0cmFpZ2h0IHRlc3QAAFR1cm4gdGVzdCBibG9ja2VkOiBvYnN0YWNsZSB2ZXJ5IGNsb3NlAABObyBlbmNvZGVyIG1vdGlvbiBmcm9tIGEgY29tbWFuZGVkIHdoZWVsAAAAAEZvcndhcmQgd2hlZWwgdGhyZXNob2xkcyBtZWFzdXJlZAAAAENhbGlicmF0aW9uIGZhaWxlZDsgY2hlY2sgbW90b3JzIGFuZCBlbmNvZGVycwAAAFR1cm4gdGVzdCBzdG9wcGVkOiBvYnN0YWNsZSB2ZXJ5IGNsb3NlAABXaGVlbCBjb3VudHMgcmV2ZXJzZWQgZHVyaW5nIHN0cmFpZ2h0IGNvbW1hbmQAAABTdHJhaWdodCB0ZXN0IHN0b3BwZWQ6IGZyb250IHdhbGwAAAAAAAAAAAAAAABAAADRQgAA1kIAAOBCAADsQgAA9EIAAPtCAAACQwAADUMAABpDAAAgQwAANUAAAOEuZUIAACDBAAC0Qv//f3/bD8k/AAAAwQAAKEIAAABBAACAPwAAgL8AAPpD7FE4vgCACUXCuDK+CZjEP8K4Mj4AAABAAABIQwAA8EEAAEBBAACgQACAO0WsxSc57FE4PtsPSUAAACBAAACAR28SgzrNzMw9AADwwQAAgEEAAAA/AADIQgAAAAAAAAAAAAAAAP///38AAAAAAAAAAAAAAAAAAACAAAAAAAAAAAAAAAAAGC1EVPshGUA="], [24572, "tTkAAA=="]]; const F={"init": 14195, "inputs": 14517, "command": 14563, "tick": 14607, "mode": 14651, "phase": 14670, "note": 14689, "calibrated": 14695, "leftPWM": 14703, "rightPWM": 14709, "leftThreshold": 14715, "rightThreshold": 14723, "backLeft": 14731, "front": 14739, "backRight": 14747, "x": 14755, "y": 14761, "theta": 14767, "construct": 14773};
const data=IMAGE.map(([a,b])=>[a,Uint8Array.from(atob(b),c=>c.charCodeAt(0))]);
const away=x=>Math.sign(x)*Math.floor(Math.abs(x)+.5);
function remainder(x,y){const q=x/y, n=Math.floor(q),half=q-n;return x-y*(half<.5?n:half>.5?n+1:n%2===0?n:n+1);}
return class BoxCore{
constructor(){
const ram=new ArrayBuffer(131072),m=new DataView(ram),bytes=new Uint8Array(ram),r=new Uint32Array(8);
for(const [i,b] of data)bytes.set(b,i);
const lanes=new ArrayBuffer(128),u=new Uint32Array(lanes),f=new Float32Array(lanes),d=new Float64Array(lanes);
const conv=new DataView(new ArrayBuffer(4));const asbits=x=>(conv.setFloat32(0,x,true),conv.getUint32(0,true));
let Z=false,C=false,S=false,O=false,oldC=false,res=0,a,b,tmp,fpv;
function flags(aa,bb,w,sub){const M=2**w,mask=M-1,hi=M/2;aa=w===32?aa>>>0:aa&mask;bb=w===32?bb>>>0:bb&mask;
 const carry=sub===2&&C?1:0, v=sub?aa-bb-carry:aa+bb; res=w===32?v>>>0:v&mask;
 Z=res===0;S=(res&hi)!==0; C=v<0||v>=M; O=(sub?((aa^bb)&(aa^res)&hi):(~(aa^bb)&(aa^res)&hi))!==0;
}
function run(pc){for(;;){switch(pc){case 4096:
flags(r[4],0x1c,32,1);r[4]=res;
m.setUint32(r[4]+0x14+0,r[3],true);
m.setUint32(r[4]+0x18+0,r[6],true);
r[3]=u[4];
f[0]=f[0]-f[8];
r[6]=u[0];
u[20]=m.getUint32(r[4]+0x24+0,true);
m.setUint32(r[4]+0,u[20],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15426);
u[12]=r[0];
u[24]=r[6];
f[12]=f[12]*f[24];
r[6]=u[12];
u[16]=r[3];
f[16]=f[16]-m.getFloat32(r[4]+0x20,true);
r[3]=u[16];
u[28]=m.getUint32(r[4]+0x24+0,true);
m.setUint32(r[4]+0,u[28],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15427);
u[0]=r[0];
u[20]=r[3];
f[0]=f[0]*f[20];
u[24]=r[6];
f[0]=f[0]+f[24];
r[3]=m.getUint32(r[4]+0x14+0,true);
r[6]=m.getUint32(r[4]+0x18+0,true);
flags(r[4],0x1c,32,0);r[4]=res;
r[4]+=4;return;

r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[0]+0,true);
flags(r[2]&r[2],0,32,0);C=O=false;
r[0]=(r[0]&~255)|((((!Z?1:0))&255)<<0);
flags(r[2],0x7,32,1);
r[2]=(r[2]&~255)|((((!Z?1:0))&255)<<0);
flags(((r[0]>>>0)&255)&((r[2]>>>0)&255),0,8,0);C=O=false;r[0]=(r[0]&~255)|(((res)&255)<<0);
r[4]+=4;return;
case 4234:
r[0]=m.getUint32(r[4]+0x4+0,true);
r[0]=m.getUint32(r[0]+0,true);
flags(r[0],0x3,32,1);
if(Z){pc=4304;continue;}
if((!C&&!Z)){pc=4271;continue;}
flags(r[0],0x1,32,1);
if(Z){pc=4311;continue;}
r[2]=0x400f;
flags(r[0],0x2,32,1);
r[0]=0x4000;
if(!Z){r[2]=r[0];}
case 4268:
r[0]=r[2];
r[4]+=4;return;
case 4271:
flags(r[0],0x5,32,1);
if(Z){pc=4318;continue;}
r[2]=0x402e;
flags(r[0],0x6,32,1);
if(Z){pc=4268;continue;}
r[2]=0x401e;
flags(r[0],0x4,32,1);
r[0]=0x4035;
if(!Z){r[2]=r[0];}
pc=4268;continue;
case 4304:
r[2]=0x4018;
pc=4268;continue;
case 4311:
r[2]=0x4005;
pc=4268;continue;
case 4318:
r[2]=0x4028;
pc=4268;continue;

case 4326:
flags(r[4],0x4,32,1);r[4]=res;
r[2]=m.getUint32(r[4]+0x8+0,true);
r[0]=m.getUint32(r[2]+0,true);
flags(r[0],0x6,32,1);
if(Z){pc=4360;continue;}
flags(r[0],0x3,32,1);r[0]=res;
flags(r[0],0x2,32,1);
if((C||Z)){pc=4372;continue;}
m.setUint32(r[4]+0,r[2],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4234);
case 4356:
flags(r[4],0x4,32,0);r[4]=res;
r[4]+=4;return;
case 4360:
r[0]=m.getUint32(r[2]+0x68+0,true);
r[0]=m.getUint32(r[0]*4+0x4760+0,true);
pc=4356;continue;
case 4372:
r[2]=m.getUint32(r[2]+0x4+0,true);
r[0]=0x403b;
flags(r[2]&r[2],0,32,0);C=O=false;
if(Z){pc=4356;continue;}
r[0]=0x4040;
flags(r[2],0x1,32,1);
r[2]=0x4050;
if(Z){r[0]=r[2];}
pc=4356;continue;
case 4402:
r[0]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(r[0]+0,0x7,true);
m.setUint8(r[0]+0xe4+0,0x0,true);
r[2]=m.getUint32(r[4]+0xc+0,true);
m.setUint32(r[0]+0xe0+0,r[2],true);
m.setUint32(r[0]+0x68+0,0x0,true);
m.setUint32(r[0]+0x70+0,0x0,true);
m.setUint32(r[0]+0x6c+0,0x0,true);
m.setUint32(r[0]+0x74+0,0x4056,true);
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
m.setUint32(r[0]+0xf4+0,0x0,true);
m.setUint32(r[0]+0xf0+0,0x0,true);
r[4]+=4;return;
case 4498:
r[0]=m.getUint32(r[4]+0x4+0,true);
flags(m.getUint32(r[0]+0,true),0x1,32,1);
if(Z){pc=4592;continue;}
case 4507:
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
m.setUint32(r[0]+0xf4+0,0x0,true);
m.setUint32(r[0]+0xf0+0,0x0,true);
m.setUint32(r[0]+0,0x0,true);
r[2]=m.getUint32(r[4]+0xc+0,true);
m.setUint32(r[0]+0xe0+0,r[2],true);
m.setUint32(r[0]+0x68+0,0x0,true);
m.setUint32(r[0]+0x70+0,0x0,true);
m.setUint32(r[0]+0x6c+0,0x0,true);
m.setUint32(r[0]+0x74+0,0x4056,true);
r[4]+=4;return;
case 4592:
m.setUint8(r[0]+0xe4+0,0x0,true);
pc=4507;continue;

case 4602:
flags(r[4],0xc,32,1);r[4]=res;
m.setUint32(r[4]+0,r[3],true);
m.setUint32(r[4]+0x4+0,r[6],true);
m.setUint32(r[4]+0x8+0,r[7],true);
r[3]=m.getUint32(r[4]+0x10+0,true);
r[7]=m.getUint32(r[4]+0x18+0,true);
r[6]=m.getUint32(r[4]+0x1c+0,true);
r[1]=0xffffff79;
flags(r[7],r[1],32,1);
if((S===O)){r[1]=r[7];}
r[0]=0x87;
flags(r[1],r[0],32,1);
if((!Z&&S===O)){r[1]=r[0];}
r[0]=0xffffff79;
flags(r[6],r[0],32,1);
if((S===O)){r[0]=r[6];}
r[2]=0x87;
flags(r[0],r[2],32,1);
if((!Z&&S===O)){r[0]=r[2];}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
f[0]=(r[1]|0);
r[2]=Math.trunc(f[0]);
m.setUint32(0x6260+0,r[2],true);
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
f[0]=(r[0]|0);
r[2]=Math.trunc(f[0]);
m.setUint32(0x6264+0,r[2],true);
flags(m.getUint32(r[3]+0xf0+0,true),0x0,32,1);
if(!Z){pc=4717;continue;}
flags(r[7]&r[7],0,32,0);C=O=false;
if(!Z){pc=4759;continue;}
case 4717:
flags(m.getUint32(r[3]+0xf4+0,true),0x0,32,1);
if(!Z){pc=4730;continue;}
flags(r[6]&r[6],0,32,0);C=O=false;
if(!Z){pc=4771;continue;}
case 4730:
m.setUint32(r[3]+0xf0+0,r[1],true);
m.setUint32(r[3]+0xf4+0,r[0],true);
r[0]=(r[0]&~255)|(((0x1)&255)<<0);
r[3]=m.getUint32(r[4]+0,true);
r[6]=m.getUint32(r[4]+0x4+0,true);
r[7]=m.getUint32(r[4]+0x8+0,true);
flags(r[4],0xc,32,0);r[4]=res;
r[4]+=4;return;
case 4759:
r[7]=m.getUint32(r[4]+0x20+0,true);
m.setUint32(r[3]+0x108+0,r[7],true);
pc=4717;continue;
case 4771:
r[6]=m.getUint32(r[4]+0x20+0,true);
m.setUint32(r[3]+0x10c+0,r[6],true);
pc=4730;continue;

case 4784:
flags(r[4],0x20,32,1);r[4]=res;
m.setUint32(r[4]+0x14+0,r[3],true);
m.setUint32(r[4]+0x18+0,r[6],true);
m.setUint32(r[4]+0x1c+0,r[7],true);
r[3]=m.getUint32(r[4]+0x24+0,true);
r[6]=m.getUint32(r[4]+0x2c+0,true);
r[2]=m.getUint32(r[3]+0,true);
flags(r[2],0x4,32,1);
r[0]=(r[0]&~255)|((((Z?1:0))&255)<<0);
r[1]=m.getUint32(r[3]+0xe8+0,true);
r[7]=m.getUint32(r[3]+0x4+0,true);
flags(r[7],0x2,32,1);
if(Z){pc=5055;continue;}
r[0]=((r[0]>>>0)&255);
r[0]=r[0]+r[0]*1-0x1;
flags(r[7],0x1,32,1);
if(Z){pc=5105;continue;}
u[8]=u[8]^u[8];u[9]=u[9]^u[9];u[10]=u[10]^u[10];u[11]=u[11]^u[11];
f[8]=(r[0]|0);
u[4]=m.getUint32(r[3]+0x38+0,true);
u[0]=u[4];u[1]=u[5];u[2]=u[6];u[3]=u[7];
f[0]=f[0]-m.getFloat32(r[3]+0xf8,true);
f[0]=f[0]*f[8];
f[0]=f[0]*m.getFloat32(0x4790,true);
u[12]=m.getUint32(0x4794+0,true);
a=f[12];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=5182;continue;}
r[7]=r[6];
flags(r[7],m.getUint32(r[3]+0x100+0,true),32,1);r[7]=res;
flags(r[7],0x270f,32,1);
if((!C&&!Z)){pc=5211;continue;}
f[4]=f[4]*f[8];
f[4]=f[4]*m.getFloat32(0x4790,true);
u[0]=u[8];u[1]=u[9];u[2]=u[10];u[3]=u[11];
f[0]=f[0]*m.getFloat32(0x4798,true);
u[12]=u[12]^u[12];u[13]=u[13]^u[13];u[14]=u[14]^u[14];u[15]=u[15]^u[15];
f[12]=(r[1]|0);
f[0]=f[0]*f[12];
f[0]=f[0]*f[8];
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=5240;continue;}
r[1]=0x4078;
flags(r[0]&r[0],0,32,0);C=O=false;
r[7]=0x405f;
if((!Z&&S===O)){r[1]=r[7];}
m.setUint32(r[3]+0xe0+0,r[1],true);
flags(r[2],0x5,32,1);
if(Z){pc=5312;continue;}
r[2]=r[0]+r[0]*4;
r[2]=r[2]+r[2]*4;
flags(r[2],r[2],32,0);r[2]=res;
case 5008:
m.setUint32(r[4]+0x10+0,r[6],true);
m.setUint32(r[4]+0xc+0,r[2],true);
r[0]=Math.imul(r[0],0xffffffce);
m.setUint32(r[4]+0x8+0,r[0],true);
r[0]=m.getUint32(r[4]+0x28+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4602);
case 5039:
r[3]=m.getUint32(r[4]+0x14+0,true);
r[6]=m.getUint32(r[4]+0x18+0,true);
r[7]=m.getUint32(r[4]+0x1c+0,true);
flags(r[4],0x20,32,0);r[4]=res;
r[4]+=4;return;
case 5055:
r[0]=r[6];
flags(r[0],m.getUint32(r[3]+0x100+0,true),32,1);r[0]=res;
flags(r[0],0x1387,32,1);
if((C||Z)){pc=5039;continue;}
oldC=C;flags(r[1],1,32,0);C=oldC;r[1]=res;
m.setUint32(r[3]+0xe8+0,r[1],true);
u[0]=m.getUint32(r[3]+0x38+0,true);
m.setUint32(r[3]+0xf8+0,u[0],true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0x100+0,r[6],true);
pc=5039;continue;
case 5105:
r[0]=r[6];
flags(r[0],m.getUint32(r[3]+0x100+0,true),32,1);r[0]=res;
flags(r[0],0xf9,32,1);
if((C||Z)){pc=5039;continue;}
flags(r[1],m.getUint32(r[3]+0xec+0,true),32,1);
if(Z){pc=5153;continue;}
m.setUint32(r[3]+0x4+0,0x2,true);
m.setUint32(r[3]+0x100+0,r[6],true);
m.setUint32(r[3]+0xe0+0,0x4368,true);
pc=5039;continue;
case 5153:
m.setUint32(r[4]+0x8+0,0x432c,true);
r[0]=m.getUint32(r[4]+0x28+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4498);
pc=5039;continue;
case 5182:
m.setUint32(r[4]+0x8+0,0x439c,true);
r[0]=m.getUint32(r[4]+0x28+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=5039;continue;
case 5211:
m.setUint32(r[4]+0x8+0,0x408a,true);
r[0]=m.getUint32(r[4]+0x28+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=5039;continue;
case 5240:
m.setUint32(r[4]+0x10+0,r[6],true);
m.setUint32(r[4]+0xc+0,0x0,true);
m.setUint32(r[4]+0x8+0,0x0,true);
r[0]=m.getUint32(r[4]+0x28+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4602);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=5039;continue;}
m.setUint32(r[3]+0x4+0,0x1,true);
m.setUint32(r[3]+0x100+0,r[6],true);
m.setUint32(r[3]+0xe0+0,0x4099,true);
pc=5039;continue;
case 5312:
r[2]=0x0;
pc=5008;continue;
r[0]=m.getUint32(r[4]+0x4+0,true);
r[0]=m.getUint32(r[0]+0,true);
r[0]=m.getUint32(r[0]*4+0x4760+0,true);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(r[0]+0,0x0,true);
m.setUint32(r[0]+0x8+0,0x0,true);
m.setUint32(r[0]+0x4+0,0x0,true);
m.setUint32(r[0]+0xc+0,0x4056,true);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(r[0]+0,0xb,true);
m.setUint32(r[0]+0x8+0,0x0,true);
m.setUint32(r[0]+0x4+0,0x0,true);
r[2]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0xc+0,r[2],true);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[4]+0xc+0,true);
r[1]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0,r[1],true);
m.setUint32(r[0]+0x1c+0,r[2],true);
m.setUint32(r[0]+0x14+0,r[2],true);
u[0]=m.getUint32(r[0]+0x30+0,true);
m.setUint32(r[0]+0x34+0,u[0],true);
u[0]=m.getUint32(r[4]+0x10+0,true);
m.setUint32(r[0]+0x40+0,u[0],true);
u[0]=m.getUint32(r[4]+0x14+0,true);
m.setUint32(r[0]+0x44+0,u[0],true);
u[0]=m.getUint32(r[4]+0x18+0,true);
m.setUint32(r[0]+0x48+0,u[0],true);
m.setUint32(r[0]+0x8+0,0x0,true);
m.setUint32(r[0]+0x4+0,0x0,true);
r[4]+=4;return;
case 5478:
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[4]+0x8+0,true);
u[0]=m.getUint32(r[4]+0xc+0,true);
u[4]=m.getUint32(r[4]+0x10+0,true);
u[8]=m.getUint32(r[4]+0x14+0,true);
m.setUint32(r[0]+0x8+0,0x0,true);
m.setUint32(r[0]+0x4+0,0x0,true);
m.setUint32(r[0]+0xc+0,0x4056,true);
u[12]=u[0];u[13]=u[1];u[14]=u[2];u[15]=u[3];
u[12]=u[12]&m.getUint32(0x4820+0,true);u[13]=u[13]&m.getUint32(0x4820+4,true);u[14]=u[14]&m.getUint32(0x4820+8,true);u[15]=u[15]&m.getUint32(0x4820+12,true);
u[16]=m.getUint32(0x479c+0,true);
a=f[16];b=f[12];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=5578;continue;}
u[12]=u[4];u[13]=u[5];u[14]=u[6];u[15]=u[7];
u[12]=u[12]&m.getUint32(0x4820+0,true);u[13]=u[13]&m.getUint32(0x4820+4,true);u[14]=u[14]&m.getUint32(0x4820+8,true);u[15]=u[15]&m.getUint32(0x4820+12,true);
a=f[16];b=f[12];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=5578;continue;}
u[12]=u[8];u[13]=u[9];u[14]=u[10];u[15]=u[11];
u[12]=u[12]&m.getUint32(0x4820+0,true);u[13]=u[13]&m.getUint32(0x4820+4,true);u[14]=u[14]&m.getUint32(0x4820+8,true);u[15]=u[15]&m.getUint32(0x4820+12,true);
a=f[16];b=f[12];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=5593;continue;}
case 5578:
m.setUint32(r[0]+0,0xb,true);
r[2]=0x40ae;
case 5589:
m.setUint32(r[0]+0xc+0,r[2],true);
r[4]+=4;return;
case 5593:
m.setUint32(r[0]+0x30+0,0x0,true);
m.setUint32(r[0]+0x18+0,r[2],true);
m.setUint32(r[0]+0x10+0,r[2],true);
m.setUint32(r[0]+0x28+0,u[0],true);
m.setUint32(r[0]+0x2c+0,u[4],true);
m.setUint32(r[0]+0x4c+0,u[8],true);
m.setUint8(r[0]+0x67+0,0x0,true);
m.setUint8(r[0]+0x66+0,0x0,true);
m.setUint8(r[0]+0x65+0,0x0,true);
m.setUint8(r[0]+0x64+0,0x0,true);
m.setUint32(r[0]+0,0x1,true);
m.setUint32(r[0]+0x1c+0,r[2],true);
m.setUint32(r[0]+0x14+0,r[2],true);
m.setUint32(r[0]+0x34+0,0x0,true);
m.setUint32(r[0]+0x40+0,u[0],true);
m.setUint32(r[0]+0x44+0,u[4],true);
m.setUint32(r[0]+0x48+0,u[8],true);
r[2]=0x40c0;
pc=5589;continue;
case 5678:
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[4]+0xc+0,true);
u[0]=m.getUint32(r[4]+0x18+0,true);
m.setUint32(r[0]+0x50+0,u[0],true);
flags(m.getUint8(r[4]+0x8+0,true),0x0,8,1);
if(!Z){pc=5744;continue;}
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
f[4]=f[4]+m.getFloat32(0x47a0,true);
m.setUint32(r[0]+0x54+0,u[4],true);
m.setUint32(r[0]+0,0x2,true);
m.setUint32(r[0]+0x1c+0,r[2],true);
m.setUint32(r[0]+0x14+0,r[2],true);
u[4]=m.getUint32(r[0]+0x30+0,true);
r[2]=0x43c8;
pc=5782;continue;
case 5744:
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
f[4]=f[4]-m.getFloat32(0x47a0,true);
m.setUint32(r[0]+0x54+0,u[4],true);
m.setUint32(r[0]+0,0x7,true);
m.setUint32(r[0]+0x1c+0,r[2],true);
m.setUint32(r[0]+0x14+0,r[2],true);
u[4]=m.getUint32(r[0]+0x30+0,true);
r[2]=0x40cd;
case 5782:
m.setUint32(r[0]+0x34+0,u[4],true);
u[4]=m.getUint32(r[4]+0x10+0,true);
m.setUint32(r[0]+0x40+0,u[4],true);
u[4]=m.getUint32(r[4]+0x14+0,true);
m.setUint32(r[0]+0x44+0,u[4],true);
m.setUint32(r[0]+0x48+0,u[0],true);
m.setUint32(r[0]+0x8+0,0x0,true);
m.setUint32(r[0]+0x4+0,0x0,true);
m.setUint8(r[0]+0x67+0,0x0,true);
m.setUint8(r[0]+0x66+0,0x0,true);
m.setUint8(r[0]+0x64+0,0x0,true);
m.setUint8(r[0]+0x65+0,0x0,true);
m.setUint32(r[0]+0xc+0,r[2],true);
r[4]+=4;return;
case 5848:
flags(r[4],0x1c,32,1);r[4]=res;
m.setUint32(r[4]+0x18+0,r[3],true);
r[3]=m.getUint32(r[4]+0x20+0,true);
m.setUint32(r[4]+0x4+0,0x40c90fdb,true);
u[0]=m.getUint32(r[4]+0x28+0,true);
f[0]=f[0]-m.getFloat32(r[4]+0x24,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15429);
u[0]=r[0];
f[0]=f[0]*m.getFloat32(0x47a8,true);
u[4]=m.getUint32(0x47a4+0,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=5973;continue;}
u[8]=m.getUint32(0x47ac+0,true);
u[4]=u[8];u[5]=u[9];u[6]=u[10];u[7]=u[11];
u[4]=f[4]<f[0]?0xffffffff:0;
u[8]=u[8]&u[4];u[9]=u[9]&u[5];u[10]=u[10]&u[6];u[11]=u[11]&u[7];
u[4]=~u[4]&u[0];u[5]=~u[5]&u[1];u[6]=~u[6]&u[2];u[7]=~u[7]&u[3];
u[4]=u[4]|u[8];u[5]=u[5]|u[9];u[6]=u[6]|u[10];u[7]=u[7]|u[11];
case 5939:
m.setUint32(r[4]+0,u[4],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15431);
r[2]=0x37;
flags(r[2],r[0],32,1);r[2]=res;
m.setUint32(r[3]+0x4+0,r[2],true);
flags(r[0],0x37,32,0);r[0]=res;
m.setUint32(r[3]+0x8+0,r[0],true);
r[3]=m.getUint32(r[4]+0x18+0,true);
flags(r[4],0x1c,32,0);r[4]=res;
r[4]+=4;return;
case 5973:
u[4]=m.getUint32(0x47a4+0,true);
pc=5939;continue;

case 5984:
flags(r[4],0x2c,32,1);r[4]=res;
m.setUint32(r[4]+0x20+0,r[3],true);
m.setUint32(r[4]+0x24+0,r[6],true);
m.setUint32(r[4]+0x28+0,r[7],true);
r[3]=m.getUint32(r[4]+0x30+0,true);
r[6]=m.getUint16(r[4]+0x48+0,true);
r[7]=m.getUint16(r[4]+0x4c+0,true);
r[0]=m.getUint32(r[3]+0,true);
r[2]=r[0]-0xa;
flags(r[2],0x1,32,1);
if((C||Z)){pc=6438;continue;}
flags(r[0]&r[0],0,32,0);C=O=false;
if(Z){pc=6438;continue;}
u[0]=m.getUint32(r[4]+0x38+0,true);
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
u[4]=m.getUint32(0x479c+0,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=6411;continue;}
u[0]=m.getUint32(r[4]+0x3c+0,true);
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=6411;continue;}
u[0]=m.getUint32(r[4]+0x40+0,true);
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=6411;continue;}
r[0]=m.getUint32(r[4]+0x34+0,true);
flags(r[0],m.getUint32(r[3]+0x18+0,true),32,1);r[0]=res;
flags(r[0],0x12c,32,1);
if((!C&&!Z)){pc=6454;continue;}
u[0]=m.getUint32(r[4]+0x3c+0,true);
f[0]=f[0]-m.getFloat32(r[3]+0x2c,true);
m.setUint32(r[4]+0x4+0,u[0],true);
u[0]=m.getUint32(r[4]+0x38+0,true);
f[0]=f[0]-m.getFloat32(r[3]+0x28,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15428);
u[0]=r[0];
f[0]=f[0]+m.getFloat32(r[3]+0x30,true);
m.setUint32(r[3]+0x30+0,u[0],true);
u[16]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x28+0,u[16],true);
u[20]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x2c+0,u[20],true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x18+0,r[0],true);
flags(r[0],m.getUint32(r[3]+0x10+0,true),32,1);r[0]=res;
flags(r[0],0x15f90,32,1);
if((!C&&!Z)){pc=6483;continue;}
a=f[0];b=m.getFloat32(0x47c0,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=6483;continue;}
r[0]=m.getUint32(r[3]+0,true);
flags(r[0],0x2,32,1);
if(Z){pc=6512;continue;}
flags(r[0],0x7,32,1);
if(Z){pc=6512;continue;}
flags(r[0],0x8,32,1);
r[2]=(r[2]&~255)|((((Z?1:0))&255)<<0);
flags(r[0],0x3,32,1);
if(Z){pc=6781;continue;}
flags(((r[2]>>>0)&255)&((r[2]>>>0)&255),0,8,0);C=O=false;
if(!Z){pc=6781;continue;}
flags(m.getUint32(r[3]+0x4+0,true),0x0,32,1);
if((Z||S!==O)){pc=6308;continue;}
flags(m.getUint32(r[3]+0x8+0,true),0x0,32,1);
if((Z||S!==O)){pc=6308;continue;}
r[0]=m.getUint32(r[4]+0x34+0,true);
flags(r[0],m.getUint32(r[3]+0x1c+0,true),32,1);r[0]=res;
flags(r[0],0x707,32,1);
if((!C&&!Z)){pc=6985;continue;}
case 6308:
r[0]=m.getUint32(r[3]+0,true);
flags(r[0],0x9,32,1);
if(Z){pc=7118;continue;}
flags(r[0],0x6,32,1);
if(Z){pc=7335;continue;}
flags(r[6],0x898,32,1);
if((!C&&!Z)){pc=7673;continue;}
flags(r[0],0x4,32,1);
if(Z){pc=7641;continue;}
u[24]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x14+0,u[24],true);
u[24]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[4]+0x10+0,u[24],true);
u[28]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[4]+0xc+0,u[28],true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[4]+0x8+0,r[0],true);
m.setUint32(r[4]+0x4+0,0x0,true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5678);
pc=6438;continue;
case 6411:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x40ae,true);
case 6438:
r[3]=m.getUint32(r[4]+0x20+0,true);
r[6]=m.getUint32(r[4]+0x24+0,true);
r[7]=m.getUint32(r[4]+0x28+0,true);
flags(r[4],0x2c,32,0);r[4]=res;
r[4]+=4;return;
case 6454:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x411e,true);
pc=6438;continue;
case 6483:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4133,true);
pc=6438;continue;
case 6512:
u[8]=m.getUint32(0x47b4+0,true);
flags(r[0],0x2,32,1);
if(Z){pc=6671;continue;}
case 6529:
u[4]=m.getUint32(r[4]+0x40+0,true);
f[4]=f[4]-m.getFloat32(r[3]+0x50,true);
f[4]=f[4]*f[8];
u[12]=m.getUint32(0x47c4+0,true);
a=f[12];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=6684;continue;}
r[2]=m.getUint32(r[4]+0x34+0,true);
flags(r[2],m.getUint32(r[3]+0x14+0,true),32,1);r[2]=res;
flags(r[2],0x1770,32,1);
if((!C&&!Z)){pc=6716;continue;}
a=f[4];b=m.getFloat32(0x47c8,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=6748;continue;}
flags(r[0],0x2,32,1);
r[0]=(r[0]&~255)|((((!Z?1:0))&255)<<0);
r[0]=((r[0]>>>0)&255);
r[0]=r[0]+r[0]*4+0x3;
m.setUint32(r[3]+0,r[0],true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x1c+0,r[0],true);
m.setUint32(r[3]+0x14+0,r[0],true);
m.setUint32(r[3]+0x34+0,u[0],true);
u[24]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x40+0,u[24],true);
u[28]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x44+0,u[28],true);
u[24]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x48+0,u[24],true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
pc=6438;continue;
case 6671:
u[8]=m.getUint32(0x47b0+0,true);
pc=6529;continue;
case 6684:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x43ec,true);
pc=6438;continue;
case 6716:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4146,true);
pc=6438;continue;
case 6748:
r[0]=0xffffffce;
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
a=f[8];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
r[2]=0x32;
if((C||Z)){r[0]=r[2];}
m.setUint32(r[3]+0x4+0,r[0],true);
flags(0,r[0],32,1);r[0]=res;
m.setUint32(r[3]+0x8+0,r[0],true);
pc=6438;continue;
case 6781:
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
r[1]=m.getUint32(r[4]+0x34+0,true);
flags(r[1],m.getUint32(r[3]+0x14+0,true),32,1);r[1]=res;
flags(r[1],0xf9,32,1);
if((C||Z)){pc=6438;continue;}
u[4]=m.getUint32(r[3]+0x54+0,true);
f[4]=f[4]-m.getFloat32(r[4]+0x40,true);
u[4]=u[4]&m.getUint32(0x4820+0,true);u[5]=u[5]&m.getUint32(0x4820+4,true);u[6]=u[6]&m.getUint32(0x4820+8,true);u[7]=u[7]&m.getUint32(0x4820+12,true);
a=f[4];b=m.getFloat32(0x47cc,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=6937;continue;}
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x4c+0,u[28],true);
flags(r[6],0xf6d,32,1);
if((!C&&!Z)){pc=6864;continue;}
flags(((r[2]>>>0)&255)&((r[2]>>>0)&255),0,8,0);C=O=false;
if(!Z){pc=6955;continue;}
case 6864:
flags(r[0],0x8,32,1);
if(Z){pc=6973;continue;}
r[2]=0x4;
r[0]=0x4106;
case 6879:
m.setUint32(r[3]+0,r[2],true);
r[1]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x1c+0,r[1],true);
m.setUint32(r[3]+0x14+0,r[1],true);
m.setUint32(r[3]+0x34+0,u[0],true);
u[28]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x40+0,u[28],true);
u[24]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x44+0,u[24],true);
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x48+0,u[28],true);
m.setUint32(r[3]+0xc+0,r[0],true);
pc=6438;continue;
case 6937:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0xc+0,0x4410,true);
pc=6438;continue;
case 6955:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0xc+0,0x4430,true);
pc=6438;continue;
case 6973:
r[2]=0x9;
r[0]=0x40ea;
pc=6879;continue;
case 6985:
u[0]=m.getUint32(r[3]+0x48+0,true);
m.setUint32(r[4]+0x4+0,u[0],true);
u[0]=m.getUint32(r[3]+0x44+0,true);
m.setUint32(r[4]+0,u[0],true);
u[8]=m.getUint32(r[3]+0x40+0,true);
u[4]=m.getUint32(r[4]+0x3c+0,true);
u[0]=m.getUint32(r[4]+0x38+0,true);
r[4]-=4;m.setUint32(r[4],0,true);run(4096);
u[4]=m.getUint32(0x47d0+0,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=7086;continue;}
u[24]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x40+0,u[24],true);
u[24]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x44+0,u[24],true);
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x48+0,u[28],true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x1c+0,r[0],true);
pc=6308;continue;
case 7086:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4154,true);
pc=6438;continue;
case 7118:
flags(r[6],0x898,32,1);
if((C||Z)){pc=7267;continue;}
u[0]=m.getUint32(r[3]+0x4c+0,true);
m.setUint32(r[4]+0x4+0,u[0],true);
u[0]=m.getUint32(r[3]+0x5c+0,true);
m.setUint32(r[4]+0,u[0],true);
u[8]=m.getUint32(r[3]+0x58+0,true);
u[4]=m.getUint32(r[4]+0x3c+0,true);
u[0]=m.getUint32(r[4]+0x38+0,true);
r[4]-=4;m.setUint32(r[4],0,true);run(4096);
a=f[0];b=m.getFloat32(0x47d4,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=7299;continue;}
m.setUint32(r[3]+0,0xa,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x1c+0,r[0],true);
m.setUint32(r[3]+0x14+0,r[0],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[3]+0x34+0,u[0],true);
u[12]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x40+0,u[12],true);
u[24]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x44+0,u[24],true);
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x48+0,u[28],true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4458,true);
pc=6438;continue;
case 7267:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4169,true);
pc=6438;continue;
case 7299:
u[0]=m.getUint32(r[3]+0x4c+0,true);
m.setUint32(r[4]+0x8+0,u[0],true);
u[12]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x4+0,u[12],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5848);
pc=6438;continue;
case 7335:
flags(r[6],0x898,32,1);
if((C||Z)){pc=7509;continue;}
flags(r[7],0xe41,32,1);
if((C||Z)){pc=7541;continue;}
u[0]=m.getUint32(r[3]+0x60+0,true);
m.setUint32(r[4]+0x4+0,u[0],true);
u[0]=m.getUint32(r[3]+0x5c+0,true);
m.setUint32(r[4]+0,u[0],true);
u[8]=m.getUint32(r[3]+0x58+0,true);
u[4]=m.getUint32(r[4]+0x3c+0,true);
u[0]=m.getUint32(r[4]+0x38+0,true);
r[4]-=4;m.setUint32(r[4],0,true);run(4096);
a=f[0];b=m.getFloat32(0x47d8,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=7573;continue;}
a=f[0];b=m.getFloat32(0x47dc,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=7605;continue;}
u[24]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x58+0,u[24],true);
u[28]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x5c+0,u[28],true);
u[12]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x14+0,u[12],true);
m.setUint32(r[4]+0x10+0,u[28],true);
u[28]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[4]+0xc+0,u[28],true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[4]+0x8+0,r[0],true);
m.setUint32(r[4]+0x4+0,0x1,true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5678);
pc=6438;continue;
case 7509:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4180,true);
pc=6438;continue;
case 7541:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4484,true);
pc=6438;continue;
case 7573:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x419b,true);
pc=6438;continue;
case 7605:
u[0]=m.getUint32(r[3]+0x60+0,true);
m.setUint32(r[4]+0x8+0,u[0],true);
u[12]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x4+0,u[12],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5848);
pc=6438;continue;
case 7641:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x44a8,true);
pc=6438;continue;
case 7673:
flags(r[0],0x1,32,1);
if(Z){pc=7740;continue;}
flags(r[0],0x4,32,1);
if(Z){pc=7740;continue;}
flags(r[0],0x5,32,1);
if(!Z){pc=6438;continue;}
flags(r[7],0xd16,32,1);
if((!C&&!Z)){pc=8050;continue;}
flags(m.getUint8(r[3]+0x64+0,true),0x0,8,1);
if(!Z){pc=8000;continue;}
m.setUint8(r[3]+0x64+0,0x1,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x20+0,r[0],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[3]+0x38+0,u[0],true);
pc=8401;continue;
case 7740:
flags(r[7],0xd16,32,1);
if((!C&&!Z)){pc=7890;continue;}
flags(m.getUint8(r[3]+0x64+0,true),0x0,8,1);
if(!Z){pc=7781;continue;}
m.setUint8(r[3]+0x64+0,0x1,true);
r[1]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x20+0,r[1],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[3]+0x38+0,u[0],true);
pc=7894;continue;
case 7781:
r[2]=m.getUint32(r[4]+0x34+0,true);
flags(r[2],m.getUint32(r[3]+0x20+0,true),32,1);r[2]=res;
flags(r[2],0x95,32,1);
if((C||Z)){pc=7894;continue;}
u[24]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x4c+0,u[24],true);
m.setUint8(r[3]+0x65+0,0x0,true);
m.setUint32(r[3]+0,0x5,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x1c+0,r[0],true);
m.setUint32(r[3]+0x14+0,r[0],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[3]+0x34+0,u[0],true);
u[28]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x40+0,u[28],true);
u[12]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x44+0,u[12],true);
m.setUint32(r[3]+0x48+0,u[24],true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x41b4,true);
pc=6438;continue;
case 7890:
m.setUint8(r[3]+0x64+0,0x0,true);
case 7894:
u[0]=m.getUint32(r[3]+0x30+0,true);
f[0]=f[0]-m.getFloat32(r[3]+0x34,true);
u[4]=m.getUint32(0x4798+0,true);
flags(r[0],0x1,32,1);
if(Z){pc=7954;continue;}
case 7917:
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=7964;continue;}
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x44c8,true);
pc=6438;continue;
case 7954:
u[4]=m.getUint32(0x47b8+0,true);
pc=7917;continue;
case 7964:
u[0]=m.getUint32(r[3]+0x4c+0,true);
m.setUint32(r[4]+0x8+0,u[0],true);
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x4+0,u[28],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5848);
pc=6438;continue;
case 8000:
r[0]=m.getUint32(r[4]+0x34+0,true);
flags(r[0],m.getUint32(r[3]+0x20+0,true),32,1);r[0]=res;
flags(r[0],0x95,32,1);
if((C||Z)){pc=8401;continue;}
u[0]=m.getUint32(r[3]+0x30+0,true);
f[0]=f[0]-m.getFloat32(r[3]+0x38,true);
a=f[0];b=m.getFloat32(0x47d8,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=8401;continue;}
m.setUint8(r[3]+0x65+0,0x1,true);
pc=8401;continue;
case 8050:
m.setUint8(r[3]+0x64+0,0x0,true);
flags(r[7],0xd79,32,1);
if((C||Z)){pc=8401;continue;}
flags(m.getUint8(r[3]+0x65+0,true),0x0,8,1);
if(Z){pc=8393;continue;}
flags(m.getUint8(r[3]+0x66+0,true),0x0,8,1);
if(!Z){pc=8119;continue;}
m.setUint8(r[3]+0x66+0,0x1,true);
u[12]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x58+0,u[12],true);
u[24]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x5c+0,u[24],true);
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x60+0,u[28],true);
case 8119:
u[0]=m.getUint32(r[3]+0x60+0,true);
m.setUint32(r[4]+0x4+0,u[0],true);
u[0]=m.getUint32(r[3]+0x5c+0,true);
m.setUint32(r[4]+0,u[0],true);
u[8]=m.getUint32(r[3]+0x58+0,true);
u[4]=m.getUint32(r[4]+0x3c+0,true);
u[0]=m.getUint32(r[4]+0x38+0,true);
r[4]-=4;m.setUint32(r[4],0,true);run(4096);
a=f[0];b=m.getFloat32(0x47d8,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=8210;continue;}
flags(r[7],0xe41,32,1);
if((C||Z)){pc=8353;continue;}
flags(m.getUint8(r[3]+0x67+0,true),0x0,8,1);
if(!Z){pc=8242;continue;}
m.setUint8(r[3]+0x67+0,0x1,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x24+0,r[0],true);
m.setUint32(r[3]+0x3c+0,u[0],true);
pc=8357;continue;
case 8210:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x44f4,true);
pc=6438;continue;
case 8242:
r[0]=m.getUint32(r[4]+0x34+0,true);
flags(r[0],m.getUint32(r[3]+0x24+0,true),32,1);r[0]=res;
flags(r[0],0x63,32,1);
if((C||Z)){pc=8357;continue;}
f[0]=f[0]-m.getFloat32(r[3]+0x3c,true);
a=f[0];b=m.getFloat32(0x47e0,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=8357;continue;}
m.setUint32(r[3]+0,0x6,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[3]+0x1c+0,r[0],true);
m.setUint32(r[3]+0x14+0,r[0],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[3]+0x34+0,u[0],true);
u[12]=m.getUint32(r[4]+0x38+0,true);
m.setUint32(r[3]+0x40+0,u[12],true);
u[24]=m.getUint32(r[4]+0x3c+0,true);
m.setUint32(r[3]+0x44+0,u[24],true);
u[28]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[3]+0x48+0,u[28],true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4528,true);
pc=6438;continue;
case 8353:
m.setUint8(r[3]+0x67+0,0x0,true);
case 8357:
u[0]=m.getUint32(r[3]+0x60+0,true);
m.setUint32(r[4]+0x8+0,u[0],true);
u[12]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x4+0,u[12],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5848);
pc=6438;continue;
case 8393:
flags(r[7],0xe41,32,1);
if((!C&&!Z)){pc=8511;continue;}
case 8401:
m.setUint8(r[3]+0x67+0,0x0,true);
m.setUint8(r[3]+0x66+0,0x0,true);
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
f[0]=(r[7]|0);
u[4]=m.getUint32(0x47e4+0,true);
f[4]=f[4]-f[0];
f[4]=f[4]*m.getFloat32(0x47e8,true);
u[0]=m.getUint32(0x47bc+0,true);
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=8475;continue;}
u[8]=m.getUint32(0x47ec+0,true);
u[0]=u[8];u[1]=u[9];u[2]=u[10];u[3]=u[11];
u[0]=f[0]<f[4]?0xffffffff:0;
u[8]=u[8]&u[0];u[9]=u[9]&u[1];u[10]=u[10]&u[2];u[11]=u[11]&u[3];
u[0]=~u[0]&u[4];u[1]=~u[1]&u[5];u[2]=~u[2]&u[6];u[3]=~u[3]&u[7];
u[0]=u[0]|u[8];u[1]=u[1]|u[9];u[2]=u[2]|u[10];u[3]=u[3]|u[11];
case 8475:
f[0]=f[0]+m.getFloat32(r[3]+0x4c,true);
m.setUint32(r[4]+0x8+0,u[0],true);
u[24]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0x4+0,u[24],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5848);
pc=6438;continue;
case 8511:
m.setUint32(r[3]+0,0xb,true);
m.setUint32(r[3]+0x8+0,0x0,true);
m.setUint32(r[3]+0x4+0,0x0,true);
m.setUint32(r[3]+0xc+0,0x4548,true);
pc=6438;continue;

case 8544:
flags(r[4],0x1c,32,1);r[4]=res;
m.setUint32(r[4]+0x10+0,r[3],true);
m.setUint32(r[4]+0x14+0,r[6],true);
m.setUint32(r[4]+0x18+0,r[7],true);
r[3]=m.getUint32(r[4]+0x20+0,true);
r[0]=m.getUint32(r[4]+0x24+0,true);
r[7]=m.getUint32(r[4]+0x28+0,true);
flags(m.getUint8(r[3]+0,true),0x0,8,1);
if(Z){pc=9137;continue;}
flags(m.getUint8(r[3]+0x2+0,true),0x0,8,1);
if(Z){pc=8819;continue;}
u[0]=m.getUint32(r[0]+0x18+0,true);
f[0]=f[0]-m.getFloat32(r[3]+0xc,true);
r[6]=u[0];
flags(m.getUint8(r[3]+0x1+0,true),0x0,8,1);
if(!Z){pc=8918;continue;}
u[0]=m.getUint32(r[0]+0,true);
f[0]=f[0]+m.getFloat32(r[0]+0x4,true);
f[0]=f[0]*m.getFloat32(0x47f0,true);
u[4]=m.getUint32(r[0]+0xc+0,true);
f[4]=f[4]*m.getFloat32(r[0]+0x8,true);
f[0]=f[0]/f[4];
f[0]=f[0]*m.getFloat32(0x47f4,true);
u[4]=r[6];
u[4]=u[4]&m.getUint32(0x4820+0,true);u[5]=u[5]&m.getUint32(0x4820+4,true);u[6]=u[6]&m.getUint32(0x4820+8,true);u[7]=u[7]&m.getUint32(0x4820+12,true);
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=9144;continue;}
case 8673:
r[0]=r[7];
flags(r[0],m.getUint32(r[3]+0x10+0,true),32,1);r[0]=res;
r[2]=((r[0]>>>0)&65535);
a=r[0];b=0x10 &31;if(b){C=((a>>>(b-1))&1)!==0;r[0]=a>>>b;Z=(r[0]===0);S=((r[0]|0)<0);O=false;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
f[0]=(r[0]|0);
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
f[4]=(r[2]|0);
f[0]=f[0]*m.getFloat32(0x47f8,true);
f[0]=f[0]+f[4];
f[0]=f[0]*m.getFloat32(0x47fc,true);
m.setUint32(r[3]+0x10+0,r[7],true);
u[4]=r[6];
f[4]=f[4]*m.getFloat32(0x47d4,true);
u[8]=m.getUint32(0x4800+0,true);
a=f[8];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=8751;continue;}
u[0]=u[8];u[1]=u[9];u[2]=u[10];u[3]=u[11];
case 8751:
f[0]=f[0]*f[4];
f[0]=f[0]+m.getFloat32(r[3]+0x14,true);
u[8]=u[4];u[9]=u[5];u[10]=u[6];u[11]=u[7];
f[8]=f[8]+f[0];
u[12]=m.getUint32(0x47d8+0,true);
a=f[12];b=f[8];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=8991;continue;}
u[12]=u[12]^u[12];u[13]=u[13]^u[13];u[14]=u[14]^u[14];u[15]=u[15]^u[15];
u[24]=r[6];
a=f[12];b=f[24];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=9053;continue;}
a=f[8];b=m.getFloat32(0x4804,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=9013;continue;}
pc=9053;continue;
case 8819:
r[2]=m.getUint32(r[0]+0x10+0,true);
m.setUint32(r[3]+0x4+0,r[2],true);
r[2]=m.getUint32(r[0]+0x14+0,true);
m.setUint32(r[3]+0x8+0,r[2],true);
r[0]=m.getUint32(r[0]+0x18+0,true);
m.setUint32(r[3]+0xc+0,r[0],true);
flags(m.getUint8(r[3]+0x1+0,true),0x0,8,1);
if(!Z){pc=8867;continue;}
case 8843:
m.setUint32(r[3]+0x10+0,r[7],true);
m.setUint32(r[3]+0x14+0,0x0,true);
m.setUint8(r[3]+0x2+0,0x1,true);
r[0]=0x0;
pc=9115;continue;
case 8867:
u[0]=m.getUint32(r[3]+0xc+0,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15427);
u[0]=r[0];
u[0]=u[0]^m.getUint32(0x4830+0,true);u[1]=u[1]^m.getUint32(0x4830+4,true);u[2]=u[2]^m.getUint32(0x4830+8,true);u[3]=u[3]^m.getUint32(0x4830+12,true);
m.setUint32(r[3]+0x18+0,u[0],true);
u[0]=m.getUint32(r[3]+0xc+0,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15426);
m.setUint32(r[3]+0x1c+0,r[0],true);
pc=8843;continue;
case 8918:
m.setUint32(r[4]+0x4+0,0x42960000,true);
u[0]=m.getUint32(r[0]+0x10+0,true);
f[0]=f[0]-m.getFloat32(r[3]+0x4,true);
f[0]=f[0]*m.getFloat32(r[3]+0x18,true);
u[4]=m.getUint32(r[0]+0x14+0,true);
f[4]=f[4]-m.getFloat32(r[3]+0x8,true);
f[4]=f[4]*m.getFloat32(r[3]+0x1c,true);
f[0]=f[0]+f[4];
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15430);
u[20]=r[6];
u[28]=r[0];
f[20]=f[20]+f[28];
r[6]=u[20];
pc=8673;continue;
case 8991:
a=f[8];b=m.getFloat32(0x4804,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=9013;continue;}
u[8]=u[8]^u[8];u[9]=u[9]^u[9];u[10]=u[10]^u[10];u[11]=u[11]^u[11];
u[28]=r[6];
a=f[28];b=f[8];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=9053;continue;}
case 9013:
u[8]=m.getUint32(0x47d8+0,true);
a=f[8];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=9029;continue;}
u[0]=u[8];u[1]=u[9];u[2]=u[10];u[3]=u[11];
case 9029:
u[8]=u[0];u[9]=u[1];u[10]=u[2];u[11]=u[3];
u[12]=m.getUint32(0x4804+0,true);
a=f[12];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=9048;continue;}
u[8]=u[12];u[9]=u[13];u[10]=u[14];u[11]=u[15];
case 9048:
m.setUint32(r[3]+0x14+0,u[8],true);
case 9053:
f[4]=f[4]+m.getFloat32(r[3]+0x14,true);
u[0]=m.getUint32(0x47d8+0,true);
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=9074;continue;}
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
case 9074:
u[0]=u[4];u[1]=u[5];u[2]=u[6];u[3]=u[7];
u[8]=m.getUint32(0x4804+0,true);
a=f[8];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=9093;continue;}
u[0]=u[8];u[1]=u[9];u[2]=u[10];u[3]=u[11];
case 9093:
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15431);
u[16]=u[16]^u[16];u[17]=u[17]^u[17];u[18]=u[18]^u[18];u[19]=u[19]^u[19];
f[16]=(r[0]|0);
r[0]=u[16];
case 9115:
r[3]=m.getUint32(r[4]+0x10+0,true);
r[6]=m.getUint32(r[4]+0x14+0,true);
r[7]=m.getUint32(r[4]+0x18+0,true);
flags(r[4],0x1c,32,0);r[4]=res;
r[4]+=4;return;
case 9131:
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
pc=9053;continue;
case 9137:
r[0]=0x0;
pc=9115;continue;
case 9144:
r[0]=r[7];
flags(r[0],m.getUint32(r[3]+0x10+0,true),32,1);r[0]=res;
r[2]=((r[0]>>>0)&65535);
a=r[0];b=0x10 &31;if(b){C=((a>>>(b-1))&1)!==0;r[0]=a>>>b;Z=(r[0]===0);S=((r[0]|0)<0);O=false;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
f[0]=(r[0]|0);
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
f[4]=(r[2]|0);
f[0]=f[0]*m.getFloat32(0x47f8,true);
f[0]=f[0]+f[4];
f[0]=f[0]*m.getFloat32(0x47fc,true);
m.setUint32(r[3]+0x10+0,r[7],true);
u[4]=m.getUint32(0x4800+0,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((!C&&!Z)){pc=9210;continue;}
u[0]=u[4];u[1]=u[5];u[2]=u[6];u[3]=u[7];
case 9210:
u[8]=u[8]^u[8];u[9]=u[9]^u[9];u[10]=u[10]^u[10];u[11]=u[11]^u[11];
f[0]=f[0]*f[8];
f[0]=f[0]+m.getFloat32(r[3]+0x14,true);
f[8]=f[8]+f[0];
u[4]=m.getUint32(0x47d8+0,true);
a=f[4];b=f[8];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=9131;continue;}
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
a=f[8];b=m.getFloat32(0x4804,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=9013;continue;}
pc=9053;continue;
case 9262:
r[0]=m.getUint32(r[4]+0x4+0,true);
m.setUint16(r[0]+0,0xffff,true);
m.setUint16(r[0]+0x2+0,0xffff,true);
m.setUint16(r[0]+0x4+0,0x0,true);
m.setUint32(r[0]+0x8+0,0x0,true);
m.setUint32(r[0]+0xc+0,0x0,true);
m.setUint32(r[0]+0x10+0,0x0,true);
m.setUint8(r[0]+0x14+0,0x0,true);
m.setUint8(r[0]+0x15+0,0x0,true);
m.setUint8(r[0]+0x16+0,0x0,true);
r[4]+=4;return;

case 9318:
flags(r[4],0x18,32,1);r[4]=res;
m.setUint32(r[4]+0x8+0,r[3],true);
m.setUint32(r[4]+0xc+0,r[6],true);
m.setUint32(r[4]+0x10+0,r[7],true);
m.setUint32(r[4]+0x14+0,r[5],true);
r[0]=m.getUint32(r[4]+0x1c+0,true);
r[2]=m.getUint8(r[0]+0x16+0,true);
flags(((r[2]>>>0)&255)&((r[2]>>>0)&255),0,8,0);C=O=false;
if(!Z){pc=9554;continue;}
r[1]=m.getUint8(r[0]+0x15+0,true);
flags(((r[1]>>>0)&255)&((r[1]>>>0)&255),0,8,0);C=O=false;
if(!Z){pc=9499;continue;}
r[2]=m.getUint8(r[0]+0x14+0,true);
flags(((r[2]>>>0)&255)&((r[2]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=9521;continue;}
r[6]=m.getUint32(0x6240+0,true);
r[3]=r[6];
flags(r[3],m.getUint32(r[0]+0x10+0,true),32,1);r[3]=res;
flags(r[3],0x12b,32,1);
if((C||Z)){pc=9673;continue;}
r[7]=m.getUint32(0x6244+0,true);
m.setUint32(r[4]+0x4+0,r[7],true);
r[7]=m.getUint32(0x6248+0,true);
m.setUint32(r[4]+0,r[7],true);
r[3]=((m.getUint16(r[0]+0x4+0,true)<<16)>>16);
flags(r[3]&r[3],0,32,0);C=O=false;
if((Z||S!==O)){pc=9677;continue;}
r[7]=m.getUint32(r[0]+0xc+0,true);
r[5]=r[7];
flags(m.getUint8(r[0]+0x1+0,true)&0x80,0,8,0);C=O=false;
if(!Z){pc=9576;continue;}
case 9446:
flags(m.getUint8(r[0]+0x3+0,true)&0x80,0,8,0);C=O=false;
if(Z){pc=9643;continue;}
case 9456:
r[7]=m.getUint32(r[4]+0,true);
flags(r[7],0x3,32,1);r[7]=res;
flags(r[7],r[5],32,1);r[7]=res;
flags(r[7],0xfffffffa,32,1);
if((!C&&!Z)){pc=9603;continue;}
m.setUint16(r[0]+0x2+0,((r[3]>>>0)&65535),true);
r[7]=((m.getUint16(r[0]+0,true)<<16)>>16);
flags(r[7]&r[7],0,32,0);C=O=false;
if(!S){pc=9643;continue;}
case 9488:
flags(r[3],0x63,32,1);
if((Z||S!==O)){pc=9684;continue;}
pc=9615;continue;
case 9499:
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
pc=9554;continue;
case 9521:
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
m.setUint8(r[0]+0x14+0,0x1,true);
r[1]=m.getUint32(0x6240+0,true);
m.setUint32(r[0]+0x10+0,r[1],true);
case 9554:
r[0]=(r[0]&~255)|(((((r[2]>>>0)&255))&255)<<0);
r[3]=m.getUint32(r[4]+0x8+0,true);
r[6]=m.getUint32(r[4]+0xc+0,true);
r[7]=m.getUint32(r[4]+0x10+0,true);
r[5]=m.getUint32(r[4]+0x14+0,true);
flags(r[4],0x18,32,0);r[4]=res;
r[4]+=4;return;
case 9576:
r[7]=m.getUint32(r[4]+0x4+0,true);
flags(r[7],0x3,32,1);r[7]=res;
flags(r[7],m.getUint32(r[0]+0x8+0,true),32,1);r[7]=res;
flags(r[7],0xfffffffa,32,1);
if((!C&&!Z)){pc=9798;continue;}
m.setUint16(r[0]+0,((r[3]>>>0)&65535),true);
pc=9446;continue;
case 9603:
r[7]=((m.getUint16(r[0]+0,true)<<16)>>16);
flags(r[7]&r[7],0,32,0);C=O=false;
if(S){pc=9488;continue;}
flags(r[3],0x63,32,1);
if((Z||S!==O)){pc=9731;continue;}
case 9615:
m.setUint8(r[0]+0x15+0,0x1,true);
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
r[2]=(r[2]&~255)|(((((r[1]>>>0)&255))&255)<<0);
pc=9554;continue;
case 9643:
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
m.setUint8(r[0]+0x16+0,0x1,true);
m.setUint8(r[0]+0x15+0,0x0,true);
pc=9554;continue;
case 9673:
r[2]=(r[2]&~255)|(((((r[1]>>>0)&255))&255)<<0);
pc=9554;continue;
case 9677:
r[7]=((m.getUint16(r[0]+0,true)<<16)>>16);
flags(r[7]&r[7],0,32,0);C=O=false;
if(!S){pc=9725;continue;}
case 9684:
oldC=C;flags(r[3],1,32,0);C=oldC;r[3]=res;
r[3]=((((r[3]>>>0)&65535)<<16)>>16);
m.setUint16(r[0]+0x4+0,((r[3]>>>0)&65535),true);
r[2]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(r[0]+0x8+0,r[2],true);
r[2]=m.getUint32(r[4]+0,true);
m.setUint32(r[0]+0xc+0,r[2],true);
flags(m.getUint8(r[0]+0x3+0,true)&0x80,0,8,0);C=O=false;
if(!Z){pc=9752;continue;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
case 9715:
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
f[4]=(r[3]|0);
pc=9768;continue;
case 9725:
flags(m.getUint8(r[0]+0x3+0,true)&0x80,0,8,0);C=O=false;
if(Z){pc=9643;continue;}
case 9731:
oldC=C;flags(r[3],1,32,0);C=oldC;r[3]=res;
r[3]=((((r[3]>>>0)&65535)<<16)>>16);
m.setUint16(r[0]+0x4+0,((r[3]>>>0)&65535),true);
r[2]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(r[0]+0x8+0,r[2],true);
r[2]=m.getUint32(r[4]+0,true);
m.setUint32(r[0]+0xc+0,r[2],true);
case 9752:
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
f[0]=(r[3]|0);
flags(r[7]&r[7],0,32,0);C=O=false;
if(S){pc=9715;continue;}
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
case 9768:
r[2]=Math.trunc(f[4]);
m.setUint32(0x6260+0,r[2],true);
r[2]=Math.trunc(f[0]);
m.setUint32(0x6264+0,r[2],true);
m.setUint32(r[0]+0x10+0,r[6],true);
r[2]=(r[2]&~255)|(((((r[1]>>>0)&255))&255)<<0);
pc=9554;continue;
case 9798:
flags(m.getUint8(r[0]+0x3+0,true)&0x80,0,8,0);C=O=false;
if(!Z){pc=9456;continue;}
r[7]=((m.getUint16(r[0]+0,true)<<16)>>16);
pc=9488;continue;
r[4]+=4;return;

r[0]=m.getUint8(r[4]+0x8+0,true);
r[0]=m.getUint32(r[0]*4+0x624c+0,true);
r[4]+=4;return;

case 9832:
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=Math.imul(m.getUint32(0x6240+0,true),0x3e8);
m.setUint32(r[0]+0,r[2],true);
r[1]=m.getUint32(0x624c+0,true);
m.setUint16(r[0]+0x8+0,((r[1]>>>0)&65535),true);
r[2]=m.getUint32(0x6250+0,true);
m.setUint16(r[0]+0xa+0,((r[2]>>>0)&65535),true);
r[1]=m.getUint32(0x625c+0,true);
m.setUint16(r[0]+0xc+0,((r[1]>>>0)&65535),true);
m.setUint32(r[0]+0x4+0,0x0,true);
r[4]+=4;return;
case 9886:
flags(r[4],0x34,32,1);r[4]=res;
m.setUint32(r[4]+0x24+0,r[3],true);
m.setUint32(r[4]+0x28+0,r[6],true);
m.setUint32(r[4]+0x2c+0,r[7],true);
m.setUint32(r[4]+0x30+0,r[5],true);
r[3]=m.getUint32(r[4]+0x38+0,true);
m.setUint8(r[3]+0xe4+0,0x0,true);
m.setUint32(r[3]+0,0x0,true);
r[6]=r[4]+0xc;
m.setUint32(r[4]+0,r[6],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9262);
r[2]=r[3]+0x8;
r[1]=r[6];
r[7]=0x17;
flags(((r[3]>>>0)&255)&0x1,0,8,0);C=O=false;
if(!Z){pc=10184;continue;}
case 9953:
flags(((r[2]>>>0)&255)&0x2,0,8,0);C=O=false;
if(!Z){pc=10209;continue;}
case 9962:
r[6]=r[7];
flags(r[6]&0xfffffffc,0,32,0);C=O=false;r[6]=res;
r[0]=0x0;
case 9972:
r[5]=m.getUint32(r[1]+r[0]*1+0,true);
m.setUint32(r[2]+r[0]*1+0,r[5],true);
flags(r[0],0x4,32,0);r[0]=res;
flags(r[0],r[6],32,1);
if(C){pc=9972;continue;}
flags(r[2],r[0],32,0);r[2]=res;
flags(r[1],r[0],32,0);r[1]=res;
r[0]=0x0;
flags(r[7]&0x2,0,32,0);C=O=false;
if(Z){pc=10013;continue;}
r[0]=m.getUint16(r[1]+0,true);
m.setUint16(r[2]+0,((r[0]>>>0)&65535),true);
r[0]=0x2;
case 10013:
flags(r[7]&0x1,0,32,0);C=O=false;
if(Z){pc=10028;continue;}
r[1]=m.getUint8(r[1]+r[0]*1+0,true);
m.setUint8(r[2]+r[0]*1+0,((r[1]>>>0)&255),true);
case 10028:
u[0]=m.getUint32(0x4808+0,true);
m.setUint32(r[3]+0x20+0,u[0],true);
m.setUint32(r[3]+0x24+0,u[0],true);
m.setUint32(r[3]+0x28+0,0x42b40000,true);
m.setUint32(r[3]+0x2c+0,0x43b32666,true);
m.setUint32(r[3]+0x30+0,0x0,true);
m.setUint32(r[3]+0x34+0,0x0,true);
m.setUint32(r[3]+0x38+0,0x0,true);
m.setUint8(r[3]+0x3c+0,0x0,true);
m.setUint32(r[3]+0x40+0,0x0,true);
m.setUint32(r[3]+0x44+0,0x0,true);
m.setUint32(r[3]+0xe0+0,0x41ca,true);
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
r[0]=m.getUint32(r[4]+0x40+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9832);
r[0]=m.getUint32(0x6240+0,true);
m.setUint32(r[3]+0x104+0,r[0],true);
m.setUint32(r[3]+0xd4+0,r[0],true);
m.setUint32(r[3]+0xdc+0,r[0],true);
r[3]=m.getUint32(r[4]+0x24+0,true);
r[6]=m.getUint32(r[4]+0x28+0,true);
r[7]=m.getUint32(r[4]+0x2c+0,true);
r[5]=m.getUint32(r[4]+0x30+0,true);
flags(r[4],0x34,32,0);r[4]=res;
r[4]+=4;return;
case 10184:
r[0]=m.getUint8(r[4]+0xc+0,true);
m.setUint8(r[3]+0x8+0,((r[0]>>>0)&255),true);
r[2]=r[2]+0x1;
r[1]=r[4]+0xd;
r[7]=0x16;
pc=9953;continue;
case 10209:
r[0]=m.getUint16(r[1]+0,true);
m.setUint16(r[2]+0,((r[0]>>>0)&65535),true);
r[2]=r[2]+0x2;
r[1]=r[1]+0x2;
flags(r[7],0x2,32,1);r[7]=res;
pc=9962;continue;

case 10230:
r[0]=m.getUint32(r[4]+0x4+0,true);
u[0]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0,u[0],true);
m.setUint32(r[0]+0x4+0,u[0],true);
u[0]=m.getUint32(r[4]+0xc+0,true);
m.setUint32(r[0]+0x8+0,u[0],true);
u[0]=m.getUint32(r[4]+0x10+0,true);
m.setUint32(r[0]+0xc+0,u[0],true);
m.setUint32(r[0]+0x10+0,0x0,true);
m.setUint32(r[0]+0x14+0,0x0,true);
m.setUint32(r[0]+0x18+0,0x0,true);
m.setUint8(r[0]+0x1c+0,0x0,true);
m.setUint32(r[0]+0x20+0,0x0,true);
m.setUint32(r[0]+0x24+0,0x0,true);
r[4]+=4;return;

r[0]=m.getUint32(r[4]+0x4+0,true);
u[0]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0,u[0],true);
r[4]+=4;return;

r[0]=m.getUint32(r[4]+0x4+0,true);
u[0]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0x4+0,u[0],true);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
u[0]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0x10+0,u[0],true);
u[0]=m.getUint32(r[4]+0xc+0,true);
m.setUint32(r[0]+0x14+0,u[0],true);
u[0]=m.getUint32(r[4]+0x10+0,true);
m.setUint32(r[0]+0x18+0,u[0],true);
m.setUint8(r[0]+0x1c+0,0x0,true);
m.setUint32(r[0]+0x20+0,0x0,true);
m.setUint32(r[0]+0x24+0,0x0,true);
r[4]+=4;return;
case 10400:
tmp=r[3];r[4]-=4;m.setUint32(r[4],tmp,true);
r[0]=m.getUint32(r[4]+0x8+0,true);
r[2]=(r[0]|0)<0?0xffffffff:0;
r[1]=m.getUint32(r[4]+0xc+0,true);
r[3]=r[1];
a=r[3];b=0x1f &31;if(b){C=((a>>>(b-1))&1)!==0;r[3]=a>>b;Z=(r[3]===0);S=((r[3]|0)<0);O=false;}
flags(r[0],r[1],32,1);r[0]=res;
flags(r[2],r[3],32,2);r[2]=res;
r[1]=0x7fffffff;
flags(r[1],r[0],32,1);
r[1]=0x0;
flags(r[1],r[2],32,2);r[1]=res;
if((S===O)){pc=10438;continue;}
oldC=C;flags(r[2],1,32,1);C=oldC;r[2]=res;
case 10436:
r[3]=m.getUint32(r[4],true);r[4]+=4;
r[4]+=4;return;
case 10438:
flags(r[0],0x80000000,32,1);
r[3]=r[2];
flags(r[3],0xffffffff,32,2);r[3]=res;
if((S===O)){pc=10436;continue;}
oldC=C;flags(r[2],1,32,0);C=oldC;r[2]=res;
pc=10436;continue;

case 10454:
flags(r[4],0x4c,32,1);r[4]=res;
m.setUint32(r[4]+0x3c+0,r[3],true);
m.setUint32(r[4]+0x40+0,r[6],true);
m.setUint32(r[4]+0x44+0,r[7],true);
m.setUint32(r[4]+0x48+0,r[5],true);
r[3]=m.getUint32(r[4]+0x50+0,true);
r[6]=m.getUint32(r[3]+0,true);
u[0]=r[6];
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
u[4]=m.getUint32(0x479c+0,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11005;continue;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
u[16]=r[6];
a=f[0];b=f[16];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=11035;continue;}
r[7]=m.getUint32(r[3]+0x4+0,true);
u[0]=r[7];
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11042;continue;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
u[20]=r[7];
a=f[0];b=f[20];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=11049;continue;}
r[5]=m.getUint32(r[3]+0x8+0,true);
u[0]=r[5];
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11056;continue;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
u[28]=r[5];
a=f[0];b=f[28];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=11063;continue;}
u[24]=m.getUint32(r[3]+0xc+0,true);
m.setUint32(r[4]+0x20+0,u[24],true);
u[0]=u[24];u[1]=u[25];u[2]=u[26];u[3]=u[27];
u[0]=u[0]&m.getUint32(0x4820+0,true);u[1]=u[1]&m.getUint32(0x4820+4,true);u[2]=u[2]&m.getUint32(0x4820+8,true);u[3]=u[3]&m.getUint32(0x4820+12,true);
a=f[4];b=f[0];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11070;continue;}
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
a=f[0];b=f[24];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=11077;continue;}
r[0]=m.getUint8(r[3]+0x1c+0,true);
m.setUint8(r[4]+0x1f+0,((r[0]>>>0)&255),true);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(!Z){pc=10682;continue;}
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[3]+0x20+0,r[0],true);
r[0]=m.getUint32(r[4]+0x58+0,true);
m.setUint32(r[3]+0x24+0,r[0],true);
m.setUint8(r[3]+0x1c+0,0x1,true);
pc=11010;continue;
case 10682:
r[0]=m.getUint32(r[3]+0x20+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(10400);
u[0]=r[0];
u[12]=r[2];
u[3]=u[13];u[2]=u[1];u[1]=u[12];
m.setUint32(r[4]+0x28+0,u[0],true);m.setUint32(r[4]+0x28+4,u[1],true);
fpv=Number(m.getBigInt64(r[4]+0x28,true));
m.setFloat32(r[4]+0x24,fpv,true);
r[0]=m.getUint32(r[3]+0x24+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
r[0]=m.getUint32(r[4]+0x58+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(10400);
r[1]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[3]+0x20+0,r[1],true);
r[1]=m.getUint32(r[4]+0x58+0,true);
m.setUint32(r[3]+0x24+0,r[1],true);
u[12]=u[12]^u[12];u[13]=u[13]^u[13];u[14]=u[14]^u[14];u[15]=u[15]^u[15];
d[6]=m.getFloat32(r[4]+0x20,true);
u[8]=u[8]^u[8];u[9]=u[9]^u[9];u[10]=u[10]^u[10];u[11]=u[11]^u[11];
d[4]=m.getFloat32(r[4]+0x24,true);
u[4]=m.getUint32(0x4840+0,true);u[5]=m.getUint32(0x4840+4,true);
d[4]=d[4]*d[2];
u[28]=r[6];
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
d[0]=f[28];
d[4]=d[4]*d[0];
d[4]=d[4]/d[6];
f[8]=d[4];
u[0]=r[0];
u[28]=r[2];
u[3]=u[29];u[2]=u[1];u[1]=u[28];
m.setUint32(r[4]+0x28+0,u[0],true);m.setUint32(r[4]+0x28+4,u[1],true);
fpv=Number(m.getBigInt64(r[4]+0x28,true));
m.setFloat32(r[4]+0x20,fpv,true);
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
d[0]=m.getFloat32(r[4]+0x20,true);
d[2]=d[2]*d[0];
u[28]=r[7];
u[0]=u[0]^u[0];u[1]=u[1]^u[1];u[2]=u[2]^u[2];u[3]=u[3]^u[3];
d[0]=f[28];
d[0]=d[0]*d[2];
d[0]=d[0]/d[6];
f[0]=d[0];
u[4]=u[8];u[5]=u[9];u[6]=u[10];u[7]=u[11];
f[4]=f[4]+f[0];
f[4]=f[4]*m.getFloat32(0x480c,true);
r[6]=u[4];
f[0]=f[0]-f[8];
u[12]=r[5];
f[0]=f[0]/f[12];
r[7]=u[0];
u[0]=m.getUint32(r[3]+0x18+0,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15426);
u[0]=r[0];
u[12]=r[6];
f[0]=f[0]*f[12];
f[0]=f[0]+m.getFloat32(r[3]+0x10,true);
m.setUint32(r[3]+0x10+0,u[0],true);
u[0]=m.getUint32(r[3]+0x18+0,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15427);
u[0]=r[0];
u[12]=r[6];
f[0]=f[0]*f[12];
f[0]=f[0]+m.getFloat32(r[3]+0x14,true);
m.setUint32(r[3]+0x14+0,u[0],true);
u[0]=r[7];
f[0]=f[0]+m.getFloat32(r[3]+0x18,true);
m.setUint32(r[3]+0x18+0,u[0],true);
pc=11010;continue;
case 11005:
m.setUint8(r[4]+0x1f+0,0x0,true);
case 11010:
r[0]=m.getUint8(r[4]+0x1f+0,true);
r[3]=m.getUint32(r[4]+0x3c+0,true);
r[6]=m.getUint32(r[4]+0x40+0,true);
r[7]=m.getUint32(r[4]+0x44+0,true);
r[5]=m.getUint32(r[4]+0x48+0,true);
flags(r[4],0x4c,32,0);r[4]=res;
r[4]+=4;return;
case 11035:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11042:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11049:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11056:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11063:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11070:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11077:
m.setUint8(r[4]+0x1f+0,0x0,true);
pc=11010;continue;
case 11084:
flags(r[4],0x1c,32,1);r[4]=res;
r[0]=m.getUint32(r[4]+0x20+0,true);
u[0]=m.getUint32(r[0]+0x20+0,true);
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
u[4]=u[4]&m.getUint32(0x4820+0,true);u[5]=u[5]&m.getUint32(0x4820+4,true);u[6]=u[6]&m.getUint32(0x4820+8,true);u[7]=u[7]&m.getUint32(0x4820+12,true);
u[8]=m.getUint32(0x479c+0,true);
a=f[8];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11333;continue;}
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=11333;continue;}
u[0]=m.getUint32(r[0]+0x24+0,true);
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
u[4]=u[4]&m.getUint32(0x4820+0,true);u[5]=u[5]&m.getUint32(0x4820+4,true);u[6]=u[6]&m.getUint32(0x4820+8,true);u[7]=u[7]&m.getUint32(0x4820+12,true);
a=f[8];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11333;continue;}
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=11333;continue;}
u[0]=m.getUint32(r[0]+0x28+0,true);
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
u[4]=u[4]&m.getUint32(0x4820+0,true);u[5]=u[5]&m.getUint32(0x4820+4,true);u[6]=u[6]&m.getUint32(0x4820+8,true);u[7]=u[7]&m.getUint32(0x4820+12,true);
a=f[8];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11333;continue;}
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=11333;continue;}
u[0]=m.getUint32(r[0]+0x2c+0,true);
u[4]=u[0];u[5]=u[1];u[6]=u[2];u[7]=u[3];
u[4]=u[4]&m.getUint32(0x4820+0,true);u[5]=u[5]&m.getUint32(0x4820+4,true);u[6]=u[6]&m.getUint32(0x4820+8,true);u[7]=u[7]&m.getUint32(0x4820+12,true);
a=f[8];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(C){pc=11333;continue;}
u[4]=u[4]^u[4];u[5]=u[5]^u[5];u[6]=u[6]^u[6];u[7]=u[7]^u[7];
a=f[0];b=f[4];Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if((C||Z)){pc=11333;continue;}
r[2]=m.getUint32(0x6244+0,true);
m.setUint32(r[0]+0x110+0,r[2],true);
m.setUint32(r[0]+0x118+0,r[2],true);
r[1]=m.getUint32(0x6248+0,true);
m.setUint32(r[0]+0x114+0,r[1],true);
m.setUint32(r[0]+0x11c+0,r[1],true);
m.setUint32(r[0]+0x30+0,0x0,true);
m.setUint32(r[0]+0x34+0,0x0,true);
m.setUint32(r[0]+0x38+0,0x0,true);
m.setUint8(r[0]+0x3c+0,0x0,true);
m.setUint32(r[0]+0x40+0,0x0,true);
m.setUint32(r[0]+0x44+0,0x0,true);
m.setUint32(r[4]+0x8+0,r[1],true);
m.setUint32(r[4]+0x4+0,r[2],true);
flags(r[0],0x20,32,0);r[0]=res;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(10454);
r[0]=(r[0]&~255)|(((0x1)&255)<<0);
pc=11359;continue;
case 11333:
m.setUint32(r[4]+0x8+0,0x41df,true);
r[2]=m.getUint32(r[4]+0x24+0,true);
m.setUint32(r[4]+0x4+0,r[2],true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
r[0]=(r[0]&~255)|(((0x0)&255)<<0);
case 11359:
flags(r[4],0x1c,32,0);r[4]=res;
r[4]+=4;return;

case 11364:
flags(r[4],0x5c,32,1);r[4]=res;
m.setUint32(r[4]+0x4c+0,r[3],true);
m.setUint32(r[4]+0x50+0,r[6],true);
m.setUint32(r[4]+0x54+0,r[7],true);
m.setUint32(r[4]+0x58+0,r[5],true);
r[6]=m.getUint32(r[4]+0x60+0,true);
r[3]=m.getUint8(r[4]+0x64+0,true);
r[2]=(r[2]&~255)|(((((r[3]>>>0)&255))&255)<<0);
flags(((r[2]>>>0)&255),0x61,8,1);r[2]=(r[2]&~255)|(((res)&255)<<0);
flags(((r[2]>>>0)&255),0x19,8,1);
if((!C&&!Z)){pc=11408;continue;}
r[0]=(r[0]&~255)|(((((r[3]>>>0)&255))&255)<<0);
flags(((r[0]>>>0)&255),0x20,8,1);r[0]=(r[0]&~255)|(((res)&255)<<0);
r[3]=(r[3]&~255)|(((((r[0]>>>0)&255))&255)<<0);
case 11408:
flags(((r[3]>>>0)&255),0x58,8,1);
if(Z){pc=11719;continue;}
flags(m.getUint32(r[6]+0,true),0x0,32,1);
if(!Z){pc=12318;continue;}
r[7]=m.getUint32(0x6240+0,true);
flags(((r[3]>>>0)&255),0x43,8,1);
if(Z){pc=11748;continue;}
r[1]=(r[1]&~255)|(((((r[3]>>>0)&255))&255)<<0);
r[0]=(r[0]&~255)|(((((r[3]>>>0)&255))&255)<<0);
flags(((r[0]>>>0)&255),0x53,8,1);r[0]=(r[0]&~255)|(((res)&255)<<0);
flags(((r[0]>>>0)&255),0x1,8,1);
if((C||Z)){pc=12295;continue;}
flags(((r[3]>>>0)&255),0x4c,8,1);
if(Z){pc=12295;continue;}
flags(((r[3]>>>0)&255),0x50,8,1);
if(Z){pc=12338;continue;}
flags(((r[3]>>>0)&255),0x47,8,1);
if(Z){pc=12338;continue;}
flags(((r[3]>>>0)&255),0x56,8,1);
if(Z){pc=11496;continue;}
flags(((r[3]>>>0)&255),0x45,8,1);
if(!Z){pc=12318;continue;}
case 11496:
flags(m.getUint8(r[6]+0xe4+0,true),0x0,8,1);
if(Z){pc=12308;continue;}
flags(((r[3]>>>0)&255),0x45,8,1);
if(!Z){pc=12010;continue;}
r[0]=((m.getUint16(r[6]+0x8+0,true)<<16)>>16);
r[2]=((m.getUint16(r[6]+0xa+0,true)<<16)>>16);
flags(r[0],r[2],32,1);
if((S!==O)){r[0]=r[2];}
flags(r[0],0x2e,32,1);
if((!Z&&S===O)){pc=11986;continue;}
case 11540:
r[0]=m.getUint32(r[4]+0x68+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[6],true);
r[4]-=4;m.setUint32(r[4],0,true);run(11084);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=12318;continue;}
r[0]=m.getUint32(r[4]+0x6c+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9832);
m.setUint32(r[6]+0xdc+0,r[7],true);
m.setUint32(r[6]+0x104+0,r[7],true);
m.setUint32(r[6]+0x10c+0,r[7],true);
m.setUint32(r[6]+0x108+0,r[7],true);
m.setUint32(r[6]+0x100+0,r[7],true);
m.setUint32(r[6]+0xfc+0,r[7],true);
m.setUint32(r[6]+0xd4+0,r[7],true);
u[0]=m.getUint32(r[6]+0x38+0,true);
m.setUint32(r[6]+0xf8+0,u[0],true);
m.setUint32(r[6]+0xe8+0,0x1,true);
m.setUint32(r[6]+0xec+0,0x1,true);
m.setUint32(r[6]+0x4+0,0x0,true);
flags(((r[3]>>>0)&255),0x53,8,1);
if(!Z){pc=12177;continue;}
r[0]=m.getUint32(r[4]+0x6c+0,true);
r[0]=m.getUint16(r[0]+0xa+0,true);
flags(r[0],0xbb8,32,1);
if((C||Z)){pc=12162;continue;}
m.setUint8(r[6]+0x48+0,0x0,true);
m.setUint8(r[6]+0x49+0,0x0,true);
m.setUint8(r[6]+0x4a+0,0x0,true);
m.setUint32(r[6]+0,0x2,true);
m.setUint32(r[6]+0xe0+0,0x4254,true);
pc=12318;continue;
case 11719:
m.setUint32(r[4]+0x8+0,0x4228,true);
r[0]=m.getUint32(r[4]+0x68+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[6],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4498);
pc=12318;continue;
case 11748:
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
m.setUint8(r[6]+0xe4+0,0x0,true);
m.setUint32(r[6]+0xf4+0,0x0,true);
m.setUint32(r[6]+0xf0+0,0x0,true);
r[3]=r[4]+0x28;
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9262);
r[2]=r[6]+0x8;
r[1]=r[3];
r[5]=0x17;
flags(r[6]&0x1,0,32,0);C=O=false;
if(!Z){pc=11941;continue;}
case 11825:
flags(((r[2]>>>0)&255)&0x2,0,8,0);C=O=false;
if(!Z){pc=11966;continue;}
case 11834:
r[3]=r[5];
flags(r[3]&0xfffffffc,0,32,0);C=O=false;r[3]=res;
r[0]=0x0;
m.setUint32(r[4]+0x60+0,r[6],true);
case 11848:
r[6]=m.getUint32(r[1]+r[0]*1+0,true);
m.setUint32(r[2]+r[0]*1+0,r[6],true);
flags(r[0],0x4,32,0);r[0]=res;
flags(r[0],r[3],32,1);
if(C){pc=11848;continue;}
r[6]=m.getUint32(r[4]+0x60+0,true);
flags(r[2],r[0],32,0);r[2]=res;
flags(r[1],r[0],32,0);r[1]=res;
r[0]=0x0;
flags(r[5]&0x2,0,32,0);C=O=false;
if(Z){pc=11893;continue;}
r[0]=m.getUint16(r[1]+0,true);
m.setUint16(r[2]+0,((r[0]>>>0)&65535),true);
r[0]=0x2;
case 11893:
flags(r[5]&0x1,0,32,0);C=O=false;
if(Z){pc=11908;continue;}
r[1]=m.getUint8(r[1]+r[0]*1+0,true);
m.setUint8(r[2]+r[0]*1+0,((r[1]>>>0)&255),true);
case 11908:
m.setUint32(r[6]+0,0x1,true);
m.setUint32(r[6]+0xe0+0,0x457c,true);
m.setUint32(r[6]+0x104+0,r[7],true);
m.setUint32(r[6]+0xd4+0,r[7],true);
pc=12318;continue;
case 11941:
r[0]=m.getUint8(r[4]+0x28+0,true);
m.setUint8(r[6]+0x8+0,((r[0]>>>0)&255),true);
r[2]=r[2]+0x1;
r[1]=r[4]+0x29;
r[5]=0x16;
pc=11825;continue;
case 11966:
r[0]=m.getUint16(r[1]+0,true);
m.setUint16(r[2]+0,((r[0]>>>0)&65535),true);
r[2]=r[2]+0x2;
r[1]=r[1]+0x2;
flags(r[5],0x2,32,1);r[5]=res;
pc=11834;continue;
case 11986:
m.setUint32(r[6]+0xe0+0,0x459c,true);
pc=12318;continue;
case 12001:
flags(((r[3]>>>0)&255),0x53,8,1);
if(Z){pc=11540;continue;}
case 12010:
r[0]=((m.getUint16(r[6]+0x8+0,true)<<16)>>16);
flags(r[0],0x31,32,1);
if((!Z&&S===O)){pc=12137;continue;}
flags(((r[1]>>>0)&255),0x47,8,1);r[1]=(r[1]&~255)|(((res)&255)<<0);
flags(((r[1]>>>0)&255),0xd,8,1);
if((C||Z)){pc=12363;continue;}
r[0]=m.getUint32(r[4]+0x68+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[6],true);
r[4]-=4;m.setUint32(r[4],0,true);run(11084);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=12318;continue;}
r[0]=m.getUint32(r[4]+0x6c+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9832);
m.setUint32(r[6]+0xdc+0,r[7],true);
m.setUint32(r[6]+0x104+0,r[7],true);
m.setUint32(r[6]+0x10c+0,r[7],true);
m.setUint32(r[6]+0x108+0,r[7],true);
m.setUint32(r[6]+0x100+0,r[7],true);
m.setUint32(r[6]+0xfc+0,r[7],true);
m.setUint32(r[6]+0xd4+0,r[7],true);
u[0]=m.getUint32(r[6]+0x38+0,true);
m.setUint32(r[6]+0xf8+0,u[0],true);
m.setUint32(r[6]+0xe8+0,0x1,true);
pc=12498;continue;
case 12137:
m.setUint32(r[6]+0xe0+0,0x45dc,true);
pc=12318;continue;
case 12152:
r[0]=0x1;
pc=12503;continue;
case 12162:
m.setUint32(r[6]+0xe0+0,0x460c,true);
pc=12318;continue;
case 12177:
m.setUint32(r[4]+0x10+0,u[0],true);
u[0]=m.getUint32(r[6]+0x34+0,true);
m.setUint32(r[4]+0xc+0,u[0],true);
u[0]=m.getUint32(r[6]+0x30+0,true);
m.setUint32(r[4]+0x8+0,u[0],true);
m.setUint32(r[4]+0x4+0,r[7],true);
r[0]=r[6]+0x68;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5478);
m.setUint32(r[6]+0,0x6,true);
m.setUint32(r[6]+0xe0+0,0x426a,true);
pc=12318;continue;
case 12238:
m.setUint32(r[6]+0xe0+0,0x4634,true);
pc=12318;continue;
case 12250:
r[2]=0x4;
r[0]=0x420d;
pc=12610;continue;
case 12265:
r[2]=0x3;
r[0]=0x41f9;
pc=12610;continue;
case 12280:
r[2]=0x3;
r[0]=0x41f9;
pc=12610;continue;
case 12295:
flags(m.getUint8(r[6]+0xe4+0,true),0x0,8,1);
if(!Z){pc=12001;continue;}
case 12308:
m.setUint32(r[6]+0xe0+0,0x423c,true);
case 12318:
r[3]=m.getUint32(r[4]+0x4c+0,true);
r[6]=m.getUint32(r[4]+0x50+0,true);
r[7]=m.getUint32(r[4]+0x54+0,true);
r[5]=m.getUint32(r[4]+0x58+0,true);
flags(r[4],0x5c,32,0);r[4]=res;
r[4]+=4;return;
case 12338:
flags(m.getUint8(r[6]+0xe4+0,true),0x0,8,1);
if(Z){pc=12308;continue;}
r[0]=((m.getUint16(r[6]+0x8+0,true)<<16)>>16);
flags(((r[1]>>>0)&255),0x47,8,1);r[1]=(r[1]&~255)|(((res)&255)<<0);
flags(r[0],0x31,32,1);
if((!Z&&S===O)){pc=12137;continue;}
case 12363:
r[0]=0x2021;
a=r[0];b=((r[1]>>>0)&255) &31;if(b){C=((a>>>(b-1))&1)!==0;r[0]=a>>>b;Z=(r[0]===0);S=((r[0]|0)<0);O=false;}
flags(((r[0]>>>0)&255)&0x1,0,8,0);C=O=false;
if(Z){pc=12387;continue;}
r[0]=((m.getUint16(r[6]+0xa+0,true)<<16)>>16);
flags(r[0],0x31,32,1);
if((!Z&&S===O)){pc=12137;continue;}
case 12387:
r[0]=m.getUint32(r[4]+0x68+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[6],true);
r[4]-=4;m.setUint32(r[4],0,true);run(11084);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=12318;continue;}
r[0]=m.getUint32(r[4]+0x6c+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9832);
m.setUint32(r[6]+0xdc+0,r[7],true);
m.setUint32(r[6]+0x104+0,r[7],true);
m.setUint32(r[6]+0x10c+0,r[7],true);
m.setUint32(r[6]+0x108+0,r[7],true);
m.setUint32(r[6]+0x100+0,r[7],true);
m.setUint32(r[6]+0xfc+0,r[7],true);
m.setUint32(r[6]+0xd4+0,r[7],true);
u[0]=m.getUint32(r[6]+0x38+0,true);
m.setUint32(r[6]+0xf8+0,u[0],true);
m.setUint32(r[6]+0xe8+0,0x1,true);
flags(((r[3]>>>0)&255),0x47,8,1);
if(Z){pc=12498;continue;}
flags(((r[3]>>>0)&255),0x56,8,1);
if(!Z){pc=12152;continue;}
case 12498:
r[0]=0x4;
case 12503:
m.setUint32(r[6]+0xec+0,r[0],true);
m.setUint32(r[6]+0x4+0,0x0,true);
r[0]=m.getUint32(r[4]+0x6c+0,true);
r[0]=m.getUint16(r[0]+0xa+0,true);
flags(r[0],0x2bc,32,1);
if((C||Z)){pc=12238;continue;}
r[0]=m.getUint32(r[4]+0x6c+0,true);
r[0]=m.getUint16(r[0]+0x8+0,true);
flags(r[0],0x2bc,32,1);
if((C||Z)){pc=12238;continue;}
r[0]=m.getUint32(r[4]+0x6c+0,true);
r[0]=m.getUint16(r[0]+0xc+0,true);
flags(r[0],0x2bc,32,1);
if((C||Z)){pc=12238;continue;}
flags(((r[3]>>>0)&255),0x4c,8,1);
if(Z){pc=12250;continue;}
flags(((r[3]>>>0)&255),0x54,8,1);
if(Z){pc=12265;continue;}
flags(((r[3]>>>0)&255),0x47,8,1);
if(Z){pc=12280;continue;}
r[2]=0x5;
r[0]=0x41f9;
case 12610:
m.setUint32(r[6]+0,r[2],true);
m.setUint32(r[6]+0xe0+0,r[0],true);
pc=12318;continue;

case 12624:
tmp=r[6];r[4]-=4;m.setUint32(r[4],tmp,true);
tmp=r[3];r[4]-=4;m.setUint32(r[4],tmp,true);
flags(r[4],0x24,32,1);r[4]=res;
r[3]=m.getUint32(r[4]+0x30+0,true);
r[6]=m.getUint32(r[4]+0x38+0,true);
r[0]=m.getUint32(0x6244+0,true);
r[2]=m.getUint32(0x6248+0,true);
flags(m.getUint32(r[3]+0x110+0,true),r[0],32,1);
if(Z){pc=12810;continue;}
case 12660:
m.setUint32(r[3]+0x108+0,r[6],true);
case 12666:
flags(m.getUint32(r[3]+0x114+0,true),r[2],32,1);
if(Z){pc=12828;continue;}
case 12678:
m.setUint32(r[3]+0x10c+0,r[6],true);
case 12684:
m.setUint32(r[3]+0x110+0,r[0],true);
m.setUint32(r[3]+0x114+0,r[2],true);
m.setUint32(r[4]+0x8+0,r[2],true);
m.setUint32(r[4]+0x4+0,r[0],true);
r[0]=r[3]+0x20;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(10454);
m.setUint8(r[4]+0x1f+0,((r[0]>>>0)&255),true);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=12846;continue;}
flags(m.getUint32(r[3]+0xf0+0,true),0x0,32,1);
if(Z){pc=12747;continue;}
r[0]=r[6];
flags(r[0],m.getUint32(r[3]+0x108+0,true),32,1);r[0]=res;
flags(r[0],0x3e7,32,1);
if((!C&&!Z)){pc=12770;continue;}
case 12747:
flags(m.getUint32(r[3]+0xf4+0,true),0x0,32,1);
if(Z){pc=12799;continue;}
flags(r[6],m.getUint32(r[3]+0x10c+0,true),32,1);r[6]=res;
flags(r[6],0x3e7,32,1);
if((C||Z)){pc=12799;continue;}
case 12770:
m.setUint32(r[4]+0x8+0,0x465c,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
m.setUint8(r[4]+0x1f+0,0x0,true);
case 12799:
r[0]=m.getUint8(r[4]+0x1f+0,true);
flags(r[4],0x24,32,0);r[4]=res;
r[3]=m.getUint32(r[4],true);r[4]+=4;
r[6]=m.getUint32(r[4],true);r[4]+=4;
r[4]+=4;return;
case 12810:
flags(m.getUint32(r[3]+0xf0+0,true),0x0,32,1);
if(!Z){pc=12666;continue;}
pc=12660;continue;
case 12828:
flags(m.getUint32(r[3]+0xf4+0,true),0x0,32,1);
if(!Z){pc=12684;continue;}
pc=12678;continue;
case 12846:
m.setUint32(r[4]+0x8+0,0x427b,true);
r[0]=m.getUint32(r[4]+0x34+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=12799;continue;
case 12872:
flags(r[4],0x4c,32,1);r[4]=res;
m.setUint32(r[4]+0x3c+0,r[3],true);
m.setUint32(r[4]+0x40+0,r[6],true);
m.setUint32(r[4]+0x44+0,r[7],true);
m.setUint32(r[4]+0x48+0,r[5],true);
r[3]=m.getUint32(r[4]+0x50+0,true);
r[6]=m.getUint32(0x6240+0,true);
r[0]=r[6];
flags(r[0],m.getUint32(r[3]+0xd4+0,true),32,1);r[0]=res;
flags(r[0],m.getUint32(r[3]+0xd0+0,true),32,1);
if(!C){pc=12937;continue;}
case 12917:
r[3]=m.getUint32(r[4]+0x3c+0,true);
r[6]=m.getUint32(r[4]+0x40+0,true);
r[7]=m.getUint32(r[4]+0x44+0,true);
r[5]=m.getUint32(r[4]+0x48+0,true);
flags(r[4],0x4c,32,0);r[4]=res;
r[4]+=4;return;
case 12937:
m.setUint32(r[3]+0xd4+0,r[6],true);
r[0]=m.getUint32(r[3]+0x104+0,true);
m.setUint32(r[4]+0x2c+0,r[0],true);
m.setUint32(r[3]+0x104+0,r[6],true);
r[5]=r[6];
flags(r[5],m.getUint32(r[3]+0xdc+0,true),32,1);r[5]=res;
r[7]=m.getUint32(r[3]+0xd8+0,true);
flags(r[5],r[7],32,1);
if(!C){pc=13153;continue;}
case 12981:
r[0]=m.getUint32(r[3]+0,true);
flags(r[0],0x7,32,1);
if(Z){pc=13176;continue;}
flags(r[0]&r[0],0,32,0);C=O=false;
if(Z){pc=12917;continue;}
r[2]=r[6];
r[1]=m.getUint32(r[4]+0x2c+0,true);
flags(r[2],r[1],32,1);r[2]=res;
flags(r[2],0x12c,32,1);
if((!C&&!Z)){pc=13201;continue;}
flags(r[0],0x1,32,1);
if(Z){pc=13230;continue;}
m.setUint32(r[4]+0x8+0,r[6],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(12624);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=12917;continue;}
r[0]=m.getUint32(r[3]+0,true);
r[2]=r[0]-0x3;
flags(r[2],0x2,32,1);
if((!C&&!Z)){pc=13349;continue;}
flags(r[5],r[7],32,1);
if(C){pc=13128;continue;}
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0xa+0,true);
flags(r[0],0x2bc,32,1);
if((C||Z)){pc=13320;continue;}
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0x8+0,true);
flags(r[0],0x2bc,32,1);
if((C||Z)){pc=13320;continue;}
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0xc+0,true);
flags(r[0],0x2bc,32,1);
if((C||Z)){pc=13320;continue;}
case 13128:
m.setUint32(r[4]+0x8+0,r[6],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4784);
pc=12917;continue;
case 13153:
r[0]=m.getUint32(r[4]+0x58+0,true);
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9832);
m.setUint32(r[3]+0xdc+0,r[6],true);
pc=12981;continue;
case 13176:
m.setUint32(0x6260+0,0x0,true);
m.setUint32(0x6264+0,0x0,true);
pc=12917;continue;
case 13201:
m.setUint32(r[4]+0x8+0,0x4293,true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=12917;continue;
case 13230:
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
r[0]=r[3]+0x8;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9318);
flags(((r[0]>>>0)&255)&((r[0]>>>0)&255),0,8,0);C=O=false;
if(Z){pc=13281;continue;}
m.setUint8(r[3]+0xe4+0,0x1,true);
m.setUint32(r[3]+0,0x0,true);
m.setUint32(r[3]+0xe0+0,0x4688,true);
pc=12917;continue;
case 13281:
flags(m.getUint8(r[3]+0x1d+0,true),0x0,8,1);
if(Z){pc=12917;continue;}
m.setUint32(r[4]+0x8+0,0x46ac,true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=12917;continue;
case 13320:
m.setUint32(r[4]+0x8+0,0x46dc,true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4498);
pc=12917;continue;
case 13349:
flags(r[0],0x2,32,1);
if(Z){pc=13528;continue;}
flags(r[5],r[7],32,1);
if(C){pc=12917;continue;}
flags(r[0],0x6,32,1);
if(!Z){pc=12917;continue;}
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0xc+0,true);
m.setUint32(r[4]+0x1c+0,r[0],true);
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0xa+0,true);
m.setUint32(r[4]+0x18+0,r[0],true);
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0x8+0,true);
m.setUint32(r[4]+0x14+0,r[0],true);
u[0]=m.getUint32(r[3]+0x38+0,true);
m.setUint32(r[4]+0x10+0,u[0],true);
u[0]=m.getUint32(r[3]+0x34+0,true);
m.setUint32(r[4]+0xc+0,u[0],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[4]+0x8+0,u[0],true);
m.setUint32(r[4]+0x4+0,r[6],true);
r[0]=r[3]+0x68;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(5984);
r[0]=m.getUint32(r[3]+0x68+0,true);
flags(r[0],0xb,32,1);
if(Z){pc=13950;continue;}
flags(r[0],0xa,32,1);
if(Z){pc=13978;continue;}
r[0]=m.getUint32(r[3]+0x74+0,true);
m.setUint32(r[3]+0xe0+0,r[0],true);
m.setUint32(r[4]+0x10+0,r[6],true);
r[0]=m.getUint32(r[3]+0x70+0,true);
m.setUint32(r[4]+0xc+0,r[0],true);
r[0]=m.getUint32(r[3]+0x6c+0,true);
m.setUint32(r[4]+0x8+0,r[0],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4602);
pc=12917;continue;
case 13528:
r[0]=m.getUint32(r[3]+0x110+0,true);
r[7]=r[0];
r[5]=r[0];
a=r[5];b=0x1f &31;if(b){C=((a>>>(b-1))&1)!==0;r[5]=a>>b;Z=(r[5]===0);S=((r[5]|0)<0);O=false;}
r[0]=m.getUint32(r[3]+0x118+0,true);
r[2]=(r[0]|0)<0?0xffffffff:0;
flags(r[7],r[0],32,1);r[7]=res;
flags(r[5],r[2],32,2);r[5]=res;
r[0]=0x7fffffff;
flags(r[0],r[7],32,1);
r[0]=0x0;
flags(r[0],r[5],32,2);r[0]=res;
if((S===O)){pc=13752;continue;}
oldC=C;flags(r[5],1,32,1);C=oldC;r[5]=res;
case 13573:
flags(r[7],0xfffffffe,32,1);
r[0]=r[5];
flags(r[0],0xffffffff,32,2);r[0]=res;
if((S!==O)){pc=13796;continue;}
case 13587:
r[0]=m.getUint32(r[3]+0x114+0,true);
r[7]=r[0];
r[5]=r[0];
a=r[5];b=0x1f &31;if(b){C=((a>>>(b-1))&1)!==0;r[5]=a>>b;Z=(r[5]===0);S=((r[5]|0)<0);O=false;}
r[0]=m.getUint32(r[3]+0x11c+0,true);
r[2]=(r[0]|0)<0?0xffffffff:0;
flags(r[7],r[0],32,1);r[7]=res;
flags(r[5],r[2],32,2);r[5]=res;
r[0]=0x7fffffff;
flags(r[0],r[7],32,1);
r[0]=0x0;
flags(r[0],r[5],32,2);r[0]=res;
if((S===O)){pc=13774;continue;}
oldC=C;flags(r[5],1,32,1);C=oldC;r[5]=res;
case 13632:
flags(r[7],0xfffffffe,32,1);
r[0]=r[5];
flags(r[0],0xffffffff,32,2);r[0]=res;
if((S!==O)){pc=13796;continue;}
case 13646:
r[0]=m.getUint32(r[4]+0x58+0,true);
r[0]=m.getUint16(r[0]+0xa+0,true);
flags(r[0],0xbb8,32,1);
if((C||Z)){pc=13825;continue;}
u[0]=m.getUint32(r[3]+0x34+0,true);
m.setUint32(r[4]+0x4+0,u[0],true);
u[0]=m.getUint32(r[3]+0x30+0,true);
m.setUint32(r[4]+0,u[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(15428);
u[0]=r[0];
a=f[0];b=m.getFloat32(0x4810,true);Z=!(a<b||a>b);C=!(a>=b);O=S=false;
if(!C){pc=13723;continue;}
r[0]=r[6];
flags(r[0],m.getUint32(r[3]+0xfc+0,true),32,1);r[0]=res;
flags(r[0],0xbb7,32,1);
if((C||Z)){pc=13854;continue;}
case 13723:
m.setUint32(r[4]+0x8+0,0x42a7,true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4498);
pc=12917;continue;
case 13752:
flags(r[7],0x80000000,32,1);
r[0]=r[5];
flags(r[0],0xffffffff,32,2);r[0]=res;
if((S!==O)){pc=13587;continue;}
pc=13573;continue;
case 13774:
flags(r[7],0x80000000,32,1);
r[0]=r[5];
flags(r[0],0xffffffff,32,2);r[0]=res;
if((S!==O)){pc=13646;continue;}
pc=13632;continue;
case 13796:
m.setUint32(r[4]+0x8+0,0x4704,true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=12917;continue;
case 13825:
m.setUint32(r[4]+0x8+0,0x4734,true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4498);
pc=12917;continue;
case 13854:
m.setUint32(r[4]+0x8+0,r[6],true);
r[0]=r[3]+0x20;
m.setUint32(r[4]+0x4+0,r[0],true);
r[0]=r[3]+0x48;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(8544);
u[4]=r[0];
r[2]=Math.trunc(f[4]);
m.setUint32(r[4]+0x10+0,r[6],true);
r[0]=((m.getUint16(r[3]+0xa+0,true)<<16)>>16);
flags(r[0],0x5,32,0);r[0]=res;
r[1]=0x64;
flags(r[0],r[1],32,1);
if((S!==O)){r[0]=r[1];}
flags(r[0],r[2],32,1);r[0]=res;
m.setUint32(r[4]+0xc+0,r[0],true);
r[0]=((m.getUint16(r[3]+0x8+0,true)<<16)>>16);
flags(r[0],0x5,32,0);r[0]=res;
flags(r[0],r[1],32,1);
if((S!==O)){r[0]=r[1];}
flags(r[0],r[2],32,0);r[0]=res;
m.setUint32(r[4]+0x8+0,r[0],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4602);
pc=12917;continue;
case 13950:
r[0]=m.getUint32(r[3]+0x74+0,true);
m.setUint32(r[4]+0x8+0,r[0],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4402);
pc=12917;continue;
case 13978:
r[0]=m.getUint32(r[3]+0x74+0,true);
m.setUint32(r[4]+0x8+0,r[0],true);
r[0]=m.getUint32(r[4]+0x54+0,true);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,r[3],true);
r[4]-=4;m.setUint32(r[4],0,true);run(4498);
pc=12917;continue;
case 14006:
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0,r[2],true);
m.setUint32(r[0]+0x4+0,0x0,true);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0,r[2],true);
r[4]+=4;return;

r[2]=m.getUint32(r[4]+0x4+0,true);
r[0]=m.getUint32(r[4]+0x8+0,true);
flags(r[0],m.getUint32(r[2]+0x4+0,true),32,1);r[0]=res;
flags(r[0],m.getUint32(r[2]+0,true),32,1);
r[0]=(r[0]&~255)|((((!C?1:0))&255)<<0);
r[4]+=4;return;

r[2]=m.getUint32(r[4]+0x4+0,true);
r[0]=m.getUint32(0x6240+0,true);
flags(r[0],m.getUint32(r[2]+0x4+0,true),32,1);r[0]=res;
flags(r[0],m.getUint32(r[2]+0,true),32,1);
r[0]=(r[0]&~255)|((((!C?1:0))&255)<<0);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(r[0]+0x4+0,r[2],true);
r[4]+=4;return;
r[0]=m.getUint32(r[4]+0x4+0,true);
r[2]=m.getUint32(0x6240+0,true);
m.setUint32(r[0]+0x4+0,r[2],true);
r[4]+=4;return;
r[0]=m.getUint32(0x6240+0,true);
r[4]+=4;return;
r[0]=Math.imul(m.getUint32(0x6240+0,true),0x3e8);
r[4]+=4;return;
r[0]=m.getUint8(r[4]+0x4+0,true);
r[0]=m.getUint32(r[0]*4+0x624c+0,true);
r[4]+=4;return;
case 14128:
r[0]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(r[0]+0x84+0,0xfa,true);
r[4]+=4;return;

r[0]=m.getUint32(0x6240+0,true);
r[4]+=4;return;
r[0]=(r[0]&~255)|(((0x0)&255)<<0);
r[4]+=4;return;

r[0]=(r[0]&~255)|(((0x1)&255)<<0);
r[4]+=4;return;

r[0]=m.getUint32(0x6244+0,true);
r[4]+=4;return;
r[0]=m.getUint32(0x6248+0,true);
r[4]+=4;return;
r[0]=Math.trunc(m.getFloat32(r[4]+0x8,true));
m.setUint32(0x6260+0,r[0],true);
r[0]=Math.trunc(m.getFloat32(r[4]+0xc,true));
m.setUint32(0x6264+0,r[0],true);
r[0]=(r[0]&~255)|(((0x1)&255)<<0);
r[4]+=4;return;
case 14195:
flags(r[4],0x134,32,1);r[4]=res;
m.setUint32(r[4]+0x130+0,r[3],true);
m.setUint32(0x625c+0,0xfff,true);
m.setUint32(0x6250+0,0xfff,true);
m.setUint32(0x624c+0,0xfff,true);
r[2]=0x0;
r[1]=0x120;
r[0]=0x0;
case 14253:
m.setUint32(r[4]+r[0]*1+0x10+0,r[2],true);
m.setUint32(r[4]+r[0]*1+0x14+0,r[2],true);
flags(r[0],0x8,32,0);r[0]=res;
flags(r[0],r[1],32,1);
if(C){pc=14253;continue;}
r[0]=r[4]+0x18;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(9262);
m.setUint32(r[4]+0xc+0,0x43b32666,true);
m.setUint32(r[4]+0x8+0,0x42b40000,true);
m.setUint32(r[4]+0x4+0,0x41800000,true);
r[0]=r[4]+0x30;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(10230);
m.setUint32(r[4]+0x5c+0,0x0,true);
m.setUint32(r[4]+0x60+0,0x0,true);
m.setUint32(r[4]+0x64+0,0x0,true);
m.setUint32(r[4]+0x4+0,0xa,true);
r[0]=r[4]+0xe0;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(14006);
m.setUint32(r[4]+0x4+0,0x32,true);
r[0]=r[4]+0xe8;
m.setUint32(r[4]+0,r[0],true);
r[4]-=4;m.setUint32(r[4],0,true);run(14006);
m.setUint32(r[4]+0x74+0,0x3f800000,true);
m.setUint32(r[4]+0x84+0,0x42be,true);
m.setUint32(r[4]+0xf0+0,0x42c4,true);
m.setUint32(r[4]+0xf8+0,0x1,true);
m.setUint32(r[4]+0xfc+0,0x1,true);
r[2]=0x120;
r[0]=0x0;
case 14448:
r[1]=m.getUint32(r[4]+r[0]*1+0x14+0,true);
r[3]=m.getUint32(r[4]+r[0]*1+0x10+0,true);
m.setUint32(r[0]+0x6000+0,r[3],true);
m.setUint32(r[0]+0x6004+0,r[1],true);
flags(r[0],0x8,32,0);r[0]=res;
flags(r[0],r[2],32,1);
if(C){pc=14448;continue;}
m.setUint32(r[4]+0x8+0,0x6120,true);
m.setUint32(r[4]+0x4+0,0x6140,true);
m.setUint32(r[4]+0,0x6000,true);
r[4]-=4;m.setUint32(r[4],0,true);run(9886);
r[3]=m.getUint32(r[4]+0x130+0,true);
flags(r[4],0x134,32,0);r[4]=res;
r[4]+=4;return;
case 14517:
r[0]=m.getUint32(r[4]+0x4+0,true);
m.setUint32(0x6244+0,r[0],true);
r[0]=m.getUint32(r[4]+0x8+0,true);
m.setUint32(0x6248+0,r[0],true);
r[0]=m.getUint32(r[4]+0xc+0,true);
m.setUint32(0x624c+0,r[0],true);
r[0]=m.getUint32(r[4]+0x10+0,true);
m.setUint32(0x6250+0,r[0],true);
r[0]=m.getUint32(r[4]+0x14+0,true);
m.setUint32(0x625c+0,r[0],true);
r[4]+=4;return;
case 14563:
flags(r[4],0x1c,32,1);r[4]=res;
m.setUint32(r[4]+0xc+0,0x6120,true);
m.setUint32(r[4]+0x8+0,0x6140,true);
r[0]=((m.getUint8(r[4]+0x20+0,true)<<24)>>24);
m.setUint32(r[4]+0x4+0,r[0],true);
m.setUint32(r[4]+0,0x6000,true);
r[4]-=4;m.setUint32(r[4],0,true);run(11364);
flags(r[4],0x1c,32,0);r[4]=res;
r[4]+=4;return;
case 14607:
flags(r[4],0x1c,32,1);r[4]=res;
r[0]=m.getUint32(r[4]+0x20+0,true);
m.setUint32(0x6240+0,r[0],true);
m.setUint32(r[4]+0x8+0,0x6120,true);
m.setUint32(r[4]+0x4+0,0x6140,true);
m.setUint32(r[4]+0,0x6000,true);
r[4]-=4;m.setUint32(r[4],0,true);run(12872);
flags(r[4],0x1c,32,0);r[4]=res;
r[4]+=4;return;
case 14651:
flags(r[4],0x4,32,1);r[4]=res;
m.setUint32(r[4]+0,0x6000,true);
r[4]-=4;m.setUint32(r[4],0,true);run(4234);
flags(r[4],0x4,32,0);r[4]=res;
r[4]+=4;return;
case 14670:
flags(r[4],0x4,32,1);r[4]=res;
m.setUint32(r[4]+0,0x6000,true);
r[4]-=4;m.setUint32(r[4],0,true);run(4326);
flags(r[4],0x4,32,0);r[4]=res;
r[4]+=4;return;
case 14689:
r[0]=m.getUint32(0x60e0+0,true);
r[4]+=4;return;
case 14695:
r[0]=m.getUint8(0x60e4+0,true);
r[4]+=4;return;
case 14703:
r[0]=m.getUint32(0x6260+0,true);
r[4]+=4;return;
case 14709:
r[0]=m.getUint32(0x6264+0,true);
r[4]+=4;return;
case 14715:
r[0]=((m.getUint16(0x6008+0,true)<<16)>>16);
r[4]+=4;return;
case 14723:
r[0]=((m.getUint16(0x600a+0,true)<<16)>>16);
r[4]+=4;return;
case 14731:
r[0]=m.getUint16(0x6128+0,true);
r[4]+=4;return;
case 14739:
r[0]=m.getUint16(0x612a+0,true);
r[4]+=4;return;
case 14747:
r[0]=m.getUint16(0x612c+0,true);
r[4]+=4;return;
case 14755:
r[0]=m.getUint32(0x6030+0,true);
r[4]+=4;return;
case 14761:
r[0]=m.getUint32(0x6034+0,true);
r[4]+=4;return;
case 14767:
r[0]=m.getUint32(0x6038+0,true);
r[4]+=4;return;
case 14773:
flags(r[4],0x10,32,1);r[4]=res;
m.setUint32(r[4]+0,0x6140,true);
r[4]-=4;m.setUint32(r[4],0,true);run(14128);
m.setUint32(0x6000+0,0x0,true);
m.setUint32(0x6004+0,0x0,true);
m.setUint32(r[4]+0,0x6008,true);
r[4]-=4;m.setUint32(r[4],0,true);run(9262);
m.setUint32(r[4]+0xc+0,0x43b32666,true);
m.setUint32(r[4]+0x8+0,0x42b40000,true);
m.setUint32(r[4]+0x4+0,0x41800000,true);
m.setUint32(r[4]+0,0x6020,true);
r[4]-=4;m.setUint32(r[4],0,true);run(10230);
m.setUint8(0x6048+0,0x0,true);
m.setUint8(0x6049+0,0x0,true);
m.setUint8(0x604a+0,0x0,true);
m.setUint32(0x604c+0,0x0,true);
m.setUint32(0x6050+0,0x0,true);
m.setUint32(0x6054+0,0x0,true);
m.setUint32(0x6058+0,0x0,true);
m.setUint32(0x605c+0,0x0,true);
m.setUint32(0x6060+0,0x0,true);
m.setUint32(0x6064+0,0x3f800000,true);
m.setUint32(0x6068+0,0x0,true);
m.setUint32(0x606c+0,0x0,true);
m.setUint32(0x6070+0,0x0,true);
m.setUint32(0x6074+0,0x42be,true);
m.setUint32(0x6078+0,0x0,true);
m.setUint32(0x607c+0,0x0,true);
m.setUint32(0x6080+0,0x0,true);
m.setUint32(0x6084+0,0x0,true);
m.setUint32(0x6088+0,0x0,true);
m.setUint32(0x608c+0,0x0,true);
m.setUint32(0x6090+0,0x0,true);
m.setUint32(0x6094+0,0x0,true);
m.setUint32(0x6098+0,0x0,true);
m.setUint32(0x609c+0,0x0,true);
m.setUint32(0x60a0+0,0x0,true);
m.setUint32(0x60a4+0,0x0,true);
m.setUint32(0x60a8+0,0x0,true);
m.setUint32(0x60ac+0,0x0,true);
m.setUint32(0x60b0+0,0x0,true);
m.setUint32(0x60b4+0,0x0,true);
m.setUint32(0x60b8+0,0x0,true);
m.setUint32(0x60bc+0,0x0,true);
m.setUint32(0x60c0+0,0x0,true);
m.setUint32(0x60c4+0,0x0,true);
m.setUint32(0x60c8+0,0x0,true);
m.setUint8(0x60cc+0,0x0,true);
m.setUint8(0x60cd+0,0x0,true);
m.setUint8(0x60ce+0,0x0,true);
m.setUint8(0x60cf+0,0x0,true);
m.setUint32(r[4]+0x4+0,0xa,true);
m.setUint32(r[4]+0,0x60d0,true);
r[4]-=4;m.setUint32(r[4],0,true);run(14006);
m.setUint32(r[4]+0x4+0,0x32,true);
m.setUint32(r[4]+0,0x60d8,true);
r[4]-=4;m.setUint32(r[4],0,true);run(14006);
m.setUint32(0x60e0+0,0x42c4,true);
m.setUint8(0x60e4+0,0x0,true);
m.setUint32(0x60e8+0,0x1,true);
m.setUint32(0x60ec+0,0x1,true);
m.setUint32(0x60f0+0,0x0,true);
m.setUint32(0x60f4+0,0x0,true);
m.setUint32(0x60f8+0,0x0,true);
m.setUint32(0x60fc+0,0x0,true);
m.setUint32(0x6100+0,0x0,true);
m.setUint32(0x6104+0,0x0,true);
m.setUint32(0x6108+0,0x0,true);
m.setUint32(0x610c+0,0x0,true);
m.setUint32(0x6110+0,0x0,true);
m.setUint32(0x6114+0,0x0,true);
m.setUint32(0x6118+0,0x0,true);
m.setUint32(0x611c+0,0x0,true);
flags(r[4],0x10,32,0);r[4]=res;
r[4]+=4;return;
case 15426:
r[0]=asbits(Math.cos(m.getFloat32(r[4]+4,true)));r[4]+=4;return;
case 15427:
r[0]=asbits(Math.sin(m.getFloat32(r[4]+4,true)));r[4]+=4;return;
case 15428:
r[0]=asbits(Math.hypot(m.getFloat32(r[4]+4,true),m.getFloat32(r[4]+8,true)));r[4]+=4;return;
case 15429:
r[0]=asbits(remainder(m.getFloat32(r[4]+4,true),m.getFloat32(r[4]+8,true)));r[4]+=4;return;
case 15430:
r[0]=asbits(Math.atan2(m.getFloat32(r[4]+4,true),m.getFloat32(r[4]+8,true)));r[4]+=4;return;
case 15431:
r[0]=away(m.getFloat32(r[4]+4,true));r[4]+=4;return;
default:throw Error('Unexpected controller address '+pc)}}}
const invoke=(name,...args)=>{r[4]=ram.byteLength-128;for(let i=0;i<args.length;i++)m.setUint32(r[4]+4+i*4,args[i],true);run(F[name]);return r[0]};
const getString=ptr=>{let s='';while(bytes[ptr])s+=String.fromCharCode(bytes[ptr++]);return s};
this._invoke=invoke;this._str=name=>getString(invoke(name));this._float=name=>(conv.setUint32(0,invoke(name),true),conv.getFloat32(0,true));
invoke('construct');invoke('init');
}
setInputs({leftTicks=0,rightTicks=0,backLeft=4095,front=4095,backRight=4095}={}){this._invoke('inputs',leftTicks,rightTicks,backLeft,front,backRight)}
command(key){this._invoke('command',String(key).charCodeAt(0));}
tick(nowMs,inputs){if(inputs)this.setInputs(inputs);this._invoke('tick',nowMs);}
snapshot(){const g=this._invoke;return {mode:this._str('mode'),phase:this._str('phase'),note:this._str('note'),calibrated:!!g('calibrated'),leftPWM:g('leftPWM')|0,rightPWM:g('rightPWM')|0,leftThreshold:g('leftThreshold')|0,rightThreshold:g('rightThreshold')|0,x:this._float('x'),y:this._float('y'),theta:this._float('theta'),backLeft:g('backLeft'),front:g('front'),backRight:g('backRight')}}
};})();
