# Tablet simulator

Extract the project on your tablet. Open `simulator/index.html` in a browser, choose **Centre**, and tap **Run escape**. The page works offline. On GitHub, clicking the file shows its source; download the file to run it locally.

| If you change… | Edit | Rebuild from the project folder |
| --- | --- | --- |
| Controls or display | `simulator/ui/` | `python3 simulator/build.py` |
| Virtual box, sensors, or motion model | `simulator/engine/world.js` and `simulator/engine/sim.js` | `python3 simulator/build.py` |
| Shared C++ controller | `firmware/BoxEscape/` | `python3 simulator/build.py --recompile` |

The C++ rebuild uses x86 Linux, GCC 14 and GNU binutils. See [engine notes](engine/README.md) for the hardware assumptions. The tablet needs only the finished HTML file.

After rebuilding, run `node simulator/tests/presets.js` from the project folder to check the example trials, then commit the changed sources and generated files together.
