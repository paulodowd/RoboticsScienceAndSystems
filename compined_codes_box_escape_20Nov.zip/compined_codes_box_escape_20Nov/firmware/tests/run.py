"""Compile the sketch as C++17 and exercise it with a fake 3Pi+ middleware and ADC.
Needs Python 3 and c++ (g++/clang++). This does not build ESP32 firmware or model IR optics.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
here=Path(__file__).resolve().parent
sketch=here.parent/'BoxEscape'
with TemporaryDirectory(prefix='boxescape-tests-') as td:
    for enabled in (0,1):
        executable=Path(td)/('combined-host-'+str(enabled))
        subprocess.run(['c++',f'-DBOX_ESCAPE_ENABLE={enabled}','-std=c++17','-O1','-Wall','-Wextra','-I',str(here/'fakes'),'-I',str(sketch),
        '-x','c++',str(sketch/'BoxEscape.ino'),*map(str,sorted(sketch.glob('*.cpp'))),str(here/'test.cpp'),
        '-o',str(executable)],check=True)
        subprocess.run([str(executable)],check=True)
