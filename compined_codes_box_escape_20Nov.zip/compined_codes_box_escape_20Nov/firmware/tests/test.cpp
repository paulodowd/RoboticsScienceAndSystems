// Host verification of production sketch logic. Hardware inputs below are deliberately synthetic.
#include "Arduino.h"
#include "Controller.h"
#include "EscapePilot.h"
#include "EscapeSettings.h"
namespace S=EscapeSettings;
#include "Robot.h"
#include "TopIR.h"
#include <cassert>
#include <cmath>
#include <iostream>
void setup();void loop();
extern Controller_c controller;extern TopIR_c topIR;extern Robot_c robot;
static bool mode(const char* desired){return std::string(controller.modeName())==desired;}
static void tick(int ms=10){hw::ms+=ms;loop();}
static void send(const std::string& line){hw::serialIn.insert(hw::serialIn.end(),line.begin(),line.end());tick();}
static void clearRoom(){hw::adc[0]=hw::adc[1]=hw::adc[4]=4095;}
static void calibrate(){
 send("C\n");assert(mode("CALIBRATE"));
 for(int i=0;i<4000&&mode("CALIBRATE");i++){
   if(hw::left>=8)++hw::leftCount;
   if(hw::right>=12)++hw::rightCount;
   tick();
 }
 assert(mode("IDLE")&&controller.calibrated());assert(controller.leftThreshold()==8&&controller.rightThreshold()==12);
 assert(hw::left==0&&hw::right==0);
}
static void exerciseController(){
 setup();assert(Serial.baud==115200);assert(mode("IDLE")&&hw::left==0&&hw::right==0);
 send("S\n");assert(mode("IDLE")&&!controller.calibrated());send("CANNOT\n");assert(mode("IDLE"));
 clearRoom();calibrate();
 hw::adc[0]=1050;hw::adc[1]=3470;hw::adc[4]=2870;for(int i=0;i<12;i++)tick();
 assert(topIR.reading.back_left==1050&&topIR.reading.front==3470&&topIR.reading.back_right==2870);clearRoom();
 for(int i=0;i<12;i++)tick();
 // Timed controller clocks vs signed absolute encoder counters from its own middleware.
 send("T\n");for(int i=0;i<20&&!(hw::left>0&&hw::right<0);i++)tick();
 assert(mode("POINT")&&hw::left>0&&hw::right<0);
 int t=0;while(mode("POINT")&&(hw::left||hw::right)&&t++<500){hw::leftCount+=2;hw::rightCount-=2;tick();}
 assert(hw::left==0&&hw::right==0);assert(mode("POINT")); // settle counts while stopped
 hw::leftCount+=3;hw::rightCount-=3;
 for(int i=0;i<30;i++)tick();
 assert(mode("IDLE"));
 auto rad=controller.odometry().pose.theta;assert(rad< -1.55f&&rad> -1.65f);
 send("L\n");for(int i=0;i<20&&!(hw::left<0&&hw::right>0);i++)tick();
 assert(mode("POINT_CCW")&&hw::left<0&&hw::right>0);
 t=0;while(mode("POINT_CCW")&&(hw::left||hw::right)&&t++<500){hw::leftCount-=2;hw::rightCount+=2;tick();}
 assert(hw::left==0&&hw::right==0&&mode("POINT_CCW"));
 hw::leftCount-=3;hw::rightCount+=3;
 for(int i=0;i<30;i++)tick();
 rad=controller.odometry().pose.theta;assert(mode("IDLE")&&rad>1.55f&&rad<1.65f);
 send("P\n");for(int i=0;i<8;i++) tick();assert(mode("PIVOT")&&hw::left>0&&hw::right==0);
 hw::button=true;tick();hw::button=false;for(int i=0;i<10;i++)tick();
 assert(mode("IDLE")&&hw::left==0&&hw::right==0);
 // Deliberate loss of fresh feedback + failed stop acknowledgement; next ticks must retry stop.
 send("S\n");for(int i=0;i<8;i++)tick();assert(mode("STRAIGHT")&&hw::left>0&&hw::right>0);
 hw::encodersOK=false;hw::stopOK=false;int n=hw::stopAttempts;for(int i=0;i<7;i++)tick();
 assert(mode("FAULT"));assert(hw::stopAttempts>n);hw::stopOK=true;for(int i=0;i<12;i++)tick();
 assert(hw::left==0&&hw::right==0&&mode("FAULT"));
 hw::encodersOK=true;send("X\n");assert(mode("IDLE")&&!controller.calibrated());
 calibrate();send("E\n");for(int i=0;i<10;i++)tick();
#if BOX_ESCAPE_ENABLE
 assert(mode("ESCAPE"));
 // Run the complete controller -> pilot -> motor -> encoder loop through one synthetic gap.
 // Scripted ADC values check the integration only; they are not a box/sensor model.
 float edge=-1;bool sawWeak=false,sawCentre=false,sawTurn=false,sawCross=false;
 for(int i=0;i<5000&&mode("ESCAPE");++i){
   std::string phase=controller.phaseName();
   sawCentre|=phase=="CENTRE";sawTurn|=phase=="TURN_RIGHT";sawCross|=phase=="CROSS";
   if(phase=="FOLLOW"&&edge<0)edge=controller.odometry().pose.x+55;
   const float dx=controller.odometry().pose.x-edge;
   if(sawTurn||(edge>=0&&dx>=12))hw::adc[4]=4095;
   else if(edge>=0&&dx>=6)hw::adc[4]=S::RIGHT_OPEN_RAW+20;
   else if(edge>=0&&dx>=0){hw::adc[4]=(S::RIGHT_EDGE_RAW+S::RIGHT_OPEN_RAW)/2;sawWeak=true;}
   else hw::adc[4]=S::RIGHT_TARGET_RAW;
   hw::leftCount+=hw::left>0?2:hw::left<0?-2:0;
   hw::rightCount+=hw::right>0?2:hw::right<0?-2:0;
   tick();
 }
 assert(sawWeak&&sawCentre&&sawTurn&&sawCross&&mode("IDLE")&&hw::left==0&&hw::right==0);
 assert(std::string(controller.note()).find("andidate")!=std::string::npos);
 clearRoom();
#else
 assert(mode("IDLE")&&hw::left==0&&hw::right==0);
#endif
 send("X\n");
 // A TCP-originated trial must stop as soon as the control client disconnects.
 hw::tcpConnected=true;
 for(int i=0;i<100;i++)tick();
 hw::tcpIn={'S','\n'};for(int i=0;i<6;i++)tick();
 assert(mode("STRAIGHT")&&hw::left>0);hw::tcpConnected=false;tick();
 assert(mode("IDLE")&&hw::left==0&&hw::right==0);
 // A close front reading during the straight test should stop forward commands.
 clearRoom();for(int i=0;i<12;i++)tick();send("S\n");for(int i=0;i<10;i++)tick();
 assert(hw::left>0&&hw::right>0);hw::adc[1]=2250;for(int i=0;i<12;i++)tick();
 assert(hw::left==0&&hw::right==0);
 clearRoom();hw::adc[4]=600;send("T\n");assert(mode("IDLE")&&hw::left==0&&hw::right==0);
 clearRoom();send("T\n");for(int i=0;i<5;i++)tick();assert(mode("POINT"));
 hw::leftCount-=40;hw::rightCount+=40;tick();assert(mode("FAULT")&&hw::left==0&&hw::right==0);
 send("X\n");calibrate();send("S\n");for(int i=0;i<5;i++)tick();assert(mode("STRAIGHT"));
 hw::leftCount-=3;tick();assert(mode("FAULT")&&hw::left==0&&hw::right==0);
 hw::adc[1]=1730;for(int i=0;i<12;i++)tick();assert(topIR.reading.front==1730);
}
static void exercisePilot();
int main(){exerciseController();exercisePilot();std::cout<<"Controller, IR, middleware and pilot host checks passed.\n";}
static void exercisePilot(){
 // Construct sensor/encoder observations, never tell the pilot the map or actual exit location.
 struct Run{
    EscapePilot p;uint32_t t=0;float x=0,y=0,h=0;
    Run(){p.begin(t,x,y,h);}
    void sample(float nx,float ny,float nh,uint16_t f,uint16_t r,uint16_t l=4095){t+=50;x=nx;y=ny;h=nh;p.update(t,x,y,h,l,f,r);}
    bool at(const char* state){return std::string(p.stateName())==state;}
    void wall(){for(int i=1;i<=14;i++)sample(x+3,0,0,4095,3000);assert(at("FOLLOW"));}
 };
 Run a;
 a.sample(1,0,0,4095,4095);assert(a.at("SEEK")&&a.p.left()>0&&a.p.right()>0);
 for(int i=0;i<9;i++)a.sample(a.x+2,0,0,4095,4095);
 assert(a.at("SEEK")); // open floor is not an exit
 a.wall();a.sample(a.x+2,0,0,4095,4095);a.sample(a.x+2,0,0,4095,3000);
 assert(a.at("FOLLOW")); // a single missing echo must not trigger a turn
 const float centre=S::OPENING_WIDTH_MM/2-S::EDGE_TO_AXLE_OFFSET_MM;
 const float firstEdge=a.x+2;
 const uint16_t edgeOnly=(S::RIGHT_EDGE_RAW+S::RIGHT_OPEN_RAW)/2;
 const uint16_t strong=S::RIGHT_OPEN_RAW+20;
 for(int i=0;i<3;i++){a.sample(firstEdge+2*i,0,0,4095,edgeOnly);assert(a.at("FOLLOW"));}
 const float firstStrong=a.x+2;
 a.sample(firstStrong,0,0,4095,strong);assert(a.at("FOLLOW"));
 a.sample(firstStrong+3,0,0,4095,strong);assert(a.at("FOLLOW"));
 a.sample(firstStrong+6,0,0,4095,strong);assert(a.at("CENTRE"));
 while(a.at("CENTRE")&&a.x-firstEdge<50)a.sample(a.x+1,0,0,4095,strong);
 // The first weak edge, not the later strong reading or full-scale return, anchors the axle.
 assert(a.at("TURN_RIGHT")&&a.x-firstEdge>=centre-S::CENTRE_TOL_MM&&a.x-firstEdge<=centre);
 assert(a.x-firstStrong<centre-S::CENTRE_TOL_MM);
 a.sample(a.x,0,-0.05,4095,4095);assert(a.p.left()>0&&a.p.right()<0);
 a.sample(a.x,0,-1.57,4095,4095);assert(a.at("SETTLE_RIGHT")&&a.p.left()==0&&a.p.right()==0);
 Run noClear=a;
 for(int i=0;i<5;i++)noClear.sample(noClear.x,0,-1.57,S::EXIT_FRONT_CLEAR_RAW-5,4095);
 assert(noClear.p.failed()&&noClear.p.left()==0&&noClear.p.right()==0);
 for(int t=0;t<5;t++)a.sample(a.x,0,-1.57,4095,4095);
 assert(a.at("CROSS"));
 for(int i=0;i<25&&!a.p.done();i++)a.sample(a.x,a.y-10,-1.57,4095,4095);
 assert(a.at("CANDIDATE")&&a.p.done()&&a.p.left()==0&&a.p.right()==0);
 Run b;b.wall();b.sample(b.x+2,0,0,1900,4095);assert(b.at("TURN_LEFT")); // corner outranks gap
 b.sample(b.x,0,0,1900,472);assert(b.at("TURN_LEFT")&&b.p.left()<0&&b.p.right()>0);
 b.sample(b.x,0,0.4f,1900,0);assert(b.at("TURN_LEFT")&&b.p.left()<0&&b.p.right()>0);
 b.sample(b.x,0,1.57,4095,3000);assert(b.at("SETTLE_LEFT"));for(int i=0;i<5;i++)b.sample(b.x,0,1.57,4095,3000);
 assert(b.at("ACQUIRE"));
 Run c;c.wall();for(int i=0;i<3;i++)c.sample(c.x+3,0,0,4095,4095);
 assert(c.at("CENTRE"));c.sample(c.x+2,0,0,4095,3000);assert(c.p.failed()&&c.p.left()==0&&c.p.right()==0);
 Run g;g.wall(); // A weak edge alone cannot carry the axle past the usable centre window.
 for(int i=0;i<30&&!g.p.failed();i++)g.sample(g.x+3,0,0,4095,edgeOnly);
 assert(g.p.failed()&&g.p.left()==0&&g.p.right()==0);
 Run d;d.sample(0,0,0,4095,4095,500);assert(d.at("SEEK")&&d.p.left()>0&&d.p.right()>0);
 d.sample(0,0,0,0,4095,500);assert(d.at("TURN_LEFT")); // low front still triggers the normal corner turn
 Run e;e.p.update(450,0,0,0,4095,4095,4095);assert(e.p.failed());
 Run f;for(int i=0;i<50&&!f.p.failed();i++)f.sample(0,0,0,4095,4095);
 assert(f.p.failed()&&f.p.left()==0&&f.p.right()==0);
}
