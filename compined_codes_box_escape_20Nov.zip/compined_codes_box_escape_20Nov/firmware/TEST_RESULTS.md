# Physical box escape — verification record

**Status:** integrated prototype for a first supervised single-box trial. The code was exercised on a computer. No board firmware was flashed here, and no physical escape has been observed with this combined sketch. First compile in ArduinoDroid for the M5StampC3, check the three raw channels, and do the motion checks in START_HERE.md.

## What the box model showed

The test calls the same C++ EscapePilot used by the sketch. It places a 100 mm circular body in a 400 × 350 mm box with a centred 150 mm opening. Its pass check uses the body's true position outside the box, independently of the pilot's own 'candidate' result. Clearance is the smallest simulated distance between the body and a wall or doorpost during a run.

| Start in model | Outcome with packaged settings | Minimum body clearance |
|---|---|---:|
| Beside the exit wall, wall on the right, 30 mm initial body clearance | Entire body outside at 6.30 s | 22.2 mm |
| Same heading, 20 mm initial body clearance | Entire body outside at 6.25 s | 18.1 mm |
| Room centre, facing the right-hand wall | Entire body outside at 21.65 s | 19.7 mm |

The old 700-count stop interrupted the second left turn. With the cutoff removed from the escape routine, the robot completes the turn and reaches the opening. The tablet simulator, which also runs the motor controller and uses quantised encoder readings, reproduces the change: at 5.05 s the back-right sensor reads 472 and turning continues. The full tablet run exits at 21.70 s with 20.19 mm minimum modelled clearance. Neither model is a physical trial.

**Why the exit detector uses an early mark:** in a second model run we moved the two back-right thresholds from 3450/3650 to 3950/4000 without remeasuring the offset. All three starts in this later-threshold sensitivity run hit a doorpost. The signal weakening tells you when to mark the axle; a stronger change confirms a candidate opening. Changing the mark changes how far the axle must travel before it turns. This model uses an approximate older IR curve, ideal rays and perfect wheel odometry. It does not establish a universal rear threshold or clearance, model motor friction/slip/coasting, or prove escape from arbitrary poses. The three scenarios are selected examples, not a success rate.

## What the integration tests check

The host build compiles the complete .ino and all the sketch's .cpp files against a simulated clock, ADC, motor/encoder middleware, and Wi-Fi transport. The harness checks both build settings for BOX_ESCAPE_ENABLE. It exercises boot without movement, gated motion and calibration, the IR pin order, turns with coasting, stops on bad feedback and command disconnect, and a full synthetic right-opening sequence. The boxed geometry experiment above is a separate test of the pilot alone.

## Reproduce on a computer (optional)

From the `firmware` folder, with Python 3 and a C++17 compiler named c++:

- `python3 tests/run.py` — compile and exercise the combined sketch with escape disabled and enabled.
- `python3 tests/pilot_box_demo.py` — run the three box starts and the later-threshold sensitivity test; add `--trace` to see phase changes.

Neither command belongs in ArduinoDroid or on the robot. For the Pad, use **BoxEscape/BoxEscape.ino** and **START_HERE.md**.
