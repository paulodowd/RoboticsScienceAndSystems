# compined_codes_box_escape_20Nov

This experiment compares one controller on the physical Stamp-C3 robot and in a tablet browser. The robot drives straight until it finds a wall, follows the wall on its right, and uses wheel odometry to turn into a candidate opening. The simulated arena is 400 × 350 mm with a 150 mm opening. This is the single-box experiment, separate from the multi-room Sim5.

| To use | Open |
| --- | --- |
| Robot in ArduinoDroid | [BoxEscape.ino](firmware/BoxEscape/BoxEscape.ino) — keep the entire sketch folder together. [Setup and commands](firmware/START_HERE.md). |
| Tablet simulation | [index.html](simulator/index.html) — download and open the file in a browser, or serve it as a static page. No build or board connection needed to run it. |
| Change the escape logic | [EscapePilot.cpp](firmware/BoxEscape/EscapePilot.cpp) and [EscapeSettings.h](firmware/BoxEscape/EscapeSettings.h). Rebuild the simulator after firmware changes; see [simulator instructions](simulator/README.md). |
| Compare physical trials | [Trial record](firmware/trial_record.csv) and [verification notes](firmware/TEST_RESULTS.md). |

**First comparison:** select **Centre** in the simulator and tap **Run escape**. Watch the back-right IR during the second left turn. The former rule that stopped escape whenever any sensor read 700 or less has been removed. The controller continues at the observed reading of 472, while front-wall and exit-path checks remain. From the centre the whole body clears the doorway in **21.70 simulated seconds** in the reference model; the wall starts at 20 and 30 mm clearance escape in 6.30 and 6.35 seconds. These are simulation results. A physical escape with this build has not been verified.

The three top IR channels are GPIO0 (back-left), GPIO1 (front) and GPIO4 (back-right). A low reading indicates a stronger return; 4095 alone does not establish that there is an exit. Motor calibration and encoder odometry are shared with the simulator. Credits and upstream revisions are in the physical setup guide; see the included [licence](LICENSE).
